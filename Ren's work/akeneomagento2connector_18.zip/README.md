# Magento 2 Akeneo Connector
With the help of this Connector, you can connect your Magento store with the Akeneo PIM software and manage thousands of products easily. You can push data from Akeneo into the Magento 2 store. It works with simple, configurable, and virtual types of products. Connector also exports the categories, attributes, configurable variations, attribute set/families, and much more.
 
### Installation
Manual Installation:
-  Unzip the respective extension zip and then merge "src" folder into akeneo project root directory.
-  Goto app/AppKernel.php and add line  
```
                new Webkul\Magento2Bundle\Magento2Bundle(),
```        
    in function registerProjectBundles()
- Goto app/config/routing.yml and add these lines at top of file
```
magento2:
        resource: "@Magento2Bundle/Resources/config/routing.yml"
        prefix:   /        
```

- Run this command after ssh to your akeneo server by terminal
```
        rm -rf ./var/cache/** && php bin/console pim:install:asset --env=prod && php bin/console assets:install web --symlink && yarn run webpack && php bin/console d:s:u --force
```        

### Documentation 
After installing this Bundle,

For Export Jobs

- Goto Magento2 Connector from Akeneo admin Menu Bar.
- Generate Api credentials for Magento2 (http://devdocs.magento.com/guides/v2.0/get-started/authentication/gs-authentication-token.html#integration-tokens)
- Add these credentials in Setup credentials tab and Save data,
- After that save Store view mapping and Attribute Mapping
- Then Goto to View Export jobs and create a job for Magento2 Connector.
- Run that job to export data to your Magento2 store.

For Import Jobs

- Goto Magento2 Connector from Akeneo admin Menu Bar.
- Generate API credentials for Magento2 (http://devdocs.magento.com/guides/v2.0/get-started/authentication/gs-authentication-token.html#integration-tokens)
- Add these credentials in Setup credentials tab and Save data,
- After that save Store view mapping and Attribute Mapping (Optional)
- Create Image Attributes and add to it in Attribute Mapping.
- Then Goto to View Import jobs and create a job for Magento2 Connector.
- Run that job to import data from your Magento2 store to Akeneo.
- Note: If you want to import product variations image then first create variant image attribute and add it to the family attributes and variant attributes then again run product import job.

