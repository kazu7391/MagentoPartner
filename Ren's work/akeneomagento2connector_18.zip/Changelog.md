# 1.2.0 - "export association product (related, cross, upsell" (19-Jun-18)
- export association products (related, cross sell, upsell) -
- 
# 1.1.9 - "special characters in url_key" (6-Jun-18)
- convert special characters in url_key to closest lowercase a-z characters or -

# 1.1.8 - "url key update" (22-May-18)
- url_key gets updated according to name
- can map stock status by mapping "in_stock" to any select/boolean attribute (select attributes with options with same label as on magento)
- Magento to Akeneo import * (feature available as Addon)

# 1.1.7 - "better metric field handling" (9-May-18)
- Can export extra inventory fields like "Qty_increments" by mapping 
- Can export metric attributes with unit. setting added in other settings tab. value example: values "5 meter" or "5",

# 1.1.6 - "fallback name setting" (30-Apr-18)
- Send Product images in the order they are selected
- Extra settings: url_key prefix and Fallback name

# 1.1.5 - "Add Multiple Magento Instances" (27-Apr-18)
- Connect Multiple Magento Instances By providing Credential in Jobs.
 
# 1.1.4 - "can map sku"
- Can map sku and can use another identifier except sku.
- Search attribute option by label (previously only by code), before creating one


# 1.1.3 - "image context issue"
- resolved image path issue for akeneo with multiple instance like (on vm hosts)

# 1.1.2 - "better image roles"
## issues/fix
- changes accrding to https://github.com/magento/magento2/issues/12999

# Updates
- support for Akeneo 2.2.x


# 1.1.1 - "better store view mapping"
- add currency mapping store view wise
- can map two or more storeviews with same locale
- option for exporting all attribute groups
- select all custom attributes option
- multiple category tree export possibility for different stores

# 1.1 - "mapping ui for custom attributes" (21-03-2018)
# Updates and issue fix
- yes/no attributes issue fix
- add dynamically more standard attributes
- mapping for images
- mapping for custom attributes
- support with magento 2.2.3


# 1.0.2 - "remove oauth dependency" (09-03-2018)
# Updates and issue fix
- Remove OAuth dependency
- Allow extra fields in JobParametes
- Full size image export instead of standard size

# 1.0.1 - "quick export, changed mapping ui" (11-02-2018)
- Quick export on product page
- Changed Mapping UI
- supports akeneo 2.1.1

# 1.0.1 - "Variant wise image" (15-01-2018)
# Features
- Added Variant wise image option, schedule price option

# 1.0.0 - "Here We Go" (01-12-2017)

## Features
- Export Categories from Akeneo to Magento 2
- Export Attributes and Attribute options from Akeneo to Magento 2
- Export Family from Akeneo to Magento 2 as Attributes set
- Export Products from Akeneo to Magento 2
- Export Variations and Attribute values for product from Akeneo to Magento 2
- Export Product Images
- Filter data to be Exported based on Category, family, Completeness, Time conditions, Identifier(sku), Language and Currency for Product Export.
