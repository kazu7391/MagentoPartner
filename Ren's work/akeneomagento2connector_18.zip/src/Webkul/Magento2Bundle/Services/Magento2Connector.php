<?php

namespace Webkul\Magento2Bundle\Services;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Webkul\Magento2Bundle\Entity;
use Webkul\Magento2Bundle\Component\Validator\ValidCredentials;
use Oro\Bundle\ConfigBundle\Entity\ConfigValue;
use Webkul\Magento2Bundle\Component\OAuthClient;
use Akeneo\Component\Batch\Model\StepExecution;

class Magento2Connector
{
    const SECTION = 'magento2_connector';

    const SECTION_STORE_MAPPING = 'magento2_store_mapping';

    const SECTION_ATTRIBUTE_MAPPING = 'magento2_attribute_mapping';

    const SECTION_STORE_SETTING = 'magento2_store_';
    const SECTION_OTHER_MAPPINGS = 'magento2_other_mapping';
    const SETTING_SECTION = 'magento2_otherSettings';

    private $requiredKeys = ['hostName', 'consumerKey', 'consumerSecret', 'authToken', 'authSecret'];
    private $stepExecution;
    private $em;

    private $container;
    private $attrGroupArray = [];    
    private $attributeOptions;   

    public function __construct(\Doctrine\ORM\EntityManager $em , $container)
    {
        $this->em = $em;
        $this->container = $container;
    }


    public function setStepExecution($stepExecution)
    {
        $this->stepExecution = $stepExecution;
    }

    public function getMagentoVersion2()
    {
        $result = $this->getCredentials();
        $hostName = $result['hostName'];
        $hostName = rtrim($hostName, '/');
        $hostName = $hostName . '/magento_version';
      
        $ch = curl_init();
        \curl_setopt($ch,CURLOPT_URL, $hostName);
        \curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        \curl_setopt($ch, CURLOPT_HEADER, 0);
        $result = curl_exec($ch);
        $result = html_entity_decode($result);
        $result = explode('/', $result);
        if(count($result)) {
            $result = explode('(', $result[1]);
            $result = trim($result[0]);
        }
        curl_close($ch);
      
        return $result;
    }

    public function getCredentials()
    {
        static $credentials;

        if(empty($credentials)) {
            
            $params = $this->stepExecution ? $this->stepExecution->getJobparameters()->all() : null;
            
            /* job wise credentials */ 
            if(!empty($this->stepExecution) && $this->stepExecution instanceOf StepExecution && 
                !empty($params['hostName']) && !empty($params['consumerKey']) && !empty($params['consumerSecret']) &&
                !empty($params['authToken']) && !empty($params['authSecret'])
                ) {
                    $repo = $this->em->getRepository('OroConfigBundle:ConfigValue');
                    $credentialsFromDB = $repo->findBy([
                        'section' => self::SECTION
                        ]);
                    
                    $credentialsFromDB = $this->indexValuesByName($credentialsFromDB);


                    $credentials = [
                        'hostName' => $params['hostName'],
                        'consumerKey' => $params['consumerKey'],
                        'consumerSecret' => $params['consumerSecret'],
                        'authToken' => $params['authToken'],
                        'authSecret' => $params['authSecret'],
                        'storeMapping' => $params['storeMapping'] ?  $params['storeMapping'] : [],
                        'storeViews' => $params['storeViews'] ?  $params['storeViews'] : [],
                        'host' => $credentialsFromDB['host'] ? $credentialsFromDB['host']  : ''
                    ];
                    
            } else {
                    /* common credentials */ 
                $repo = $this->em->getRepository('OroConfigBundle:ConfigValue');
                $credentials = $repo->findBy([
                    'section' => self::SECTION
                    ]);
                    
                $credentials = $this->indexValuesByName($credentials);
                /* storeviews */ 
                $storeMapping = $repo->findOneBy([
                    'section' => self::SECTION_STORE_MAPPING,
                    'name' => 'storeMapping',
                    ]);

                $credentials['storeMapping'] = $storeMapping ? json_decode($storeMapping->getValue(), true) : [];    
            }
            
        }
        
        return $credentials;
    }

    public function getAttributeMappings()
    {
        $repo = $this->em->getRepository('OroConfigBundle:ConfigValue');        
        $attrMappings = $repo->findBy([
            'section' => self::SECTION_ATTRIBUTE_MAPPING
            ]);

        return $this->indexValuesByName($attrMappings);
    }

    public function saveAttributeMappings($attributeData)
    {
        $repo = $this->em->getRepository('OroConfigBundle:ConfigValue');

        /* remove extra mapping not recieved in new save request */ 
        $extraMappings = array_diff(array_keys($this->getAttributeMappings()), array_keys($attributeData));
        foreach($extraMappings as $mCode => $aCode) {
            $mapping = $repo->findOneBy([
                'name' => $aCode,
                'section' => self::SECTION_ATTRIBUTE_MAPPING
            ]);
            if($mapping) {
                $this->em->remove($mapping);
            }
        }

        /* save attribute mappings */
        foreach($attributeData as $mCode => $aCode) {
            $mCode = strip_tags($mCode);
            $aCode = strip_tags($aCode);
            
            $attribute = $repo->findOneBy([
                'name' => $mCode,
                'section' => self::SECTION_ATTRIBUTE_MAPPING
            ]);
            if(strpos($aCode, ' ') && $attribute) {
                $this->em->remove($attribute);
                continue;
            }

            if($attribute) {
                $attribute->setValue($aCode);
                $this->em->persist($attribute);
            } else {
                $attribute = new ConfigValue();
                $attribute->setSection(self::SECTION_ATTRIBUTE_MAPPING);
                $attribute->setName($mCode);
                $attribute->setValue($aCode);
                $this->em->persist($attribute);
            }
        }

        $this->em->flush();
    }

    public function checkCredentialAndGetStoreViews($params)
    {  
        if(is_array($params) && $this->array_keys_exists($this->requiredKeys, $params) ) {
            return $this->fetchStoreApi($params);
        }
    }

    public function saveOtherSettings($params)
    {
        if(is_array($params) && $this->array_keys_exists($this->requiredKeys, $params) ) {
            $configs = json_decode($this->fetchStoreApi($params, $params['hostName'] . '/rest/V1/store/storeConfigs?'), true);
            $setting = [];
            foreach($configs as $config) {
                $setting[$config['code']] = [];
                foreach(['locale', 'base_currency_code', 'weight_unit'] as $property) {
                    if(isset($config[$property])) {
                        $setting[$config['code']][$property] = $config[$property]; 
                    }
                }
            }
            $repo = $this->em->getRepository('OroConfigBundle:ConfigValue');

            $configValue = $repo->findOneBy([
                'section' => self::SECTION_STORE_SETTING,
                'name' => 'settings',
            ]);
            if($configValue) {
                $configValue->setValue(json_encode($setting));
            } else {
                $configValue = new ConfigValue();
                $configValue->setValue(json_encode($setting));
                $configValue->setSection(self::SECTION_STORE_SETTING);
                $configValue->setName('settings');
            }
            $this->em->persist($configValue);            
            
            $this->em->flush();
        }        
    }

    public function getOtherSettings()
    {
        static $otherSettings;

        if(empty($otherSettings)) {
            $repo = $this->em->getRepository('OroConfigBundle:ConfigValue');

            $configValue = $repo->findOneBy([
                'section' => self::SECTION_STORE_SETTING,
                'name' => 'settings',
            ]);
            $otherSettings = $configValue && $configValue->getValue() ? json_decode($configValue->getValue(), true) : null;
        }

        return $otherSettings;
    }    

    public function saveSettings($params, $section = self::SETTING_SECTION)
    {
        $repo = $this->em->getRepository('OroConfigBundle:ConfigValue');
        foreach($params as $key => $value) {
            if(gettype($value) === 'array') {
                $value = json_encode($value);
            }

            if(gettype($value) == 'string' || "NULL" === gettype($value)) {
                $field = $repo->findOneBy([
                    'section' => $section,
                    'name' => $key,
                    ]);
                    
                if(null != $value) {
                    if(!$field) {
                        $field = new ConfigValue();
                    }
                    $field->setName($key);
                    $field->setSection($section);
                    $field->setValue($value);
                    $this->em->persist($field);
                } else if($field) {
                    $this->em->remove($field);
                }
            }

            $this->em->flush();                             
        }
    }

    public function getSettings($section = self::SETTING_SECTION)
    {
        $repo = $this->em->getRepository('OroConfigBundle:ConfigValue');
        if(empty($this->settings[$section])) {
            $configs = $repo->findBy([
                'section' => $section
                ]);
                
                $this->settings[$section] = $this->indexValuesByName($configs);
        }
        
        return $this->settings[$section];
    }  


    public function saveOtherMappings($params)
    {
        $repo = $this->em->getRepository('OroConfigBundle:ConfigValue');
        
        $configValue = $repo->findOneBy([
            'section' => self::SECTION_OTHER_MAPPINGS,
            'name'    => 'otherMappings',
        ]);
        if($configValue) {
            $configValue->setValue(json_encode($params));
        } else {
            $configValue = new ConfigValue();
            $configValue->setValue(json_encode($params));
            $configValue->setSection(self::SECTION_OTHER_MAPPINGS);
            $configValue->setName('otherMappings');
        }
        $this->em->persist($configValue);
        $this->em->flush();
    }

    public function getOtherMappings()
    {
        static $otherMappings;

        if(empty($otherMappings)) {
            $repo = $this->em->getRepository('OroConfigBundle:ConfigValue');

            $configValue = $repo->findOneBy([
                'section' => self::SECTION_OTHER_MAPPINGS,
                'name' => 'otherMappings',
            ]);

            $otherMappings = $configValue && $configValue->getValue() ? json_decode($configValue->getValue(), true) : null;
        }

        return $otherMappings;
    }

    public function findChannelByIdentifier($channelCode)
    {
        return $this->em->getRepository('PimCatalogBundle:Channel')->findOneByIdentifier($channelCode);
    }    

    public function getStoreMapping()
    {
        $credentials = $this->getCredentials();   
        $storeMapping = !empty($credentials['storeMapping']) ? $credentials['storeMapping'] : [];
        $storeMapping = array_filter($storeMapping);

        return $storeMapping;
    }

    public function getIdentifierAttributeCode()
    {
        $identifierAttr = $this->em->getRepository('PimCatalogBundle:Attribute')->findOneByType('pim_catalog_identifier');
        
        return $identifierAttr ? $identifierAttr->getCode() : null;
    }

    public function getAttributeByCode($attrCode)
    {
        return $this->em->getRepository('PimCatalogBundle:Attribute')->findOneByIdentifier($attrCode);
    }


    public function getSelectTypeAttributes()
    {
        return array_merge($this->em->getRepository('PimCatalogBundle:Attribute')->getAttributeCodesByType('pim_catalog_simpleselect'),
            $this->em->getRepository('PimCatalogBundle:Attribute')->getAttributeCodesByType('pim_catalog_multiselect')
        );
    } 


    public function getGroupByAttributeCode($attrCode)
    {
        if(!isset($this->attrGroupArray[$attrCode])) {
            $attribute = $this->getAttributeByCode($attrCode);
            $group = $attribute->getGroup();
            if(!$group) {
                $this->useFallBackGroupFetchMethod();
            } else {
                $this->attrGroupArray[$attrCode] = $group;
            }
        }

        return !empty($this->attrGroupArray[$attrCode]) ? $this->attrGroupArray[$attrCode] : null;
    }

    private function useFallBackGroupFetchMethod()
    {
        $groups = $this->em->getRepository('PimCatalogBundle:AttributeGroup')->findAll();
        foreach($groups as $group) {
            $attrs = $group->getAttributes();
            foreach($attrs as $attr) {
                $code = $attr->getCode();
                $this->attrGroupArray[$code] = $group; 
            }
        }
    }


    public function getFamilyByCode($code)
    {
        return $this->em->getRepository('PimCatalogBundle:Family')->findOneByIdentifier($code);
    }

    public function getFamilyVariantByIdentifier($identifier)
    {
        return $this->container->get('pim_catalog.repository.family_variant')->findOneByIdentifier($identifier); 
    }

    private function fetchStoreApi($params, $url = null)
    {
        try {
            $oauthClient = new OAuthClient($params['authToken']);
            if(empty($url)) {
                $url = $params['hostName'] . '/rest/V1/store/storeViews?';
            }

            $oauthClient->fetch($url, [], 'GET', ['Content-Type' => 'application/json', 'Accept' => 'application/json'] );

            $results = $oauthClient->getLastResponse();
        } catch(\Exception $e) {
            $results = null;
        }
        return $results;
    }

    private function array_keys_exists(array $keys, array $arr )
    {
        $flag = true;
        foreach($keys as $key) {
            if(!array_key_exists($key, $arr)) {
                $flag = false;
                break;
            }
        }

        return $flag;
    }

    private function indexValuesByName($values) 
    {
        $result = [];
        foreach($values as $value) {
            $result[$value->getName()] = $value->getValue();
        }    
        return $result;
    }


    public function findCodeByExternalId($externalId, $entity){

        $apiUrl = $this->getApiUrl();
        $mapping = $this->em->getRepository('Magento2Bundle:DataMapping')->findOneBy([
            'externalId'   => $externalId,
            'entityType' => $entity,
            'apiUrl' => $apiUrl,
        ]);
         
        return $mapping ? $mapping->getCode() : null;
    }

    // check category code present in db 
    public function matchCategoryCodeInDb($code){
        
        $results = $this->em->createQueryBuilder()
                    ->select('c.code as code')
                    ->from('PimCatalogBundle:Category', 'c')
                    ->where('c.code = :code')
                    ->setParameter('code', $code)
                    ->getQuery()->getResult();
        
        if($results){
            foreach($results as $result){
                if(!empty($result['code'])){
                    return $result['code'];
                }
            }
        }else{
            return null;
        }
    }

    public function convertToCode($name)
    {
        setlocale(LC_ALL, 'en_US.utf8');
        $name = iconv('utf-8', 'ascii//TRANSLIT', $name);
        $name = preg_replace('/[^a-zA-Z0-9\']/', '_', $name);
        $name = ltrim($name, '_');
        $code = preg_replace(['#\s#', '#-#', '#[^a-zA-Z0-9_\s]#'], ['_', '_', ''], strtolower($name));
        
        return $code;
    }

    public function attributeOptionCheckInDB($optionCode , $code)
    {
        $results = $this->em->createQueryBuilder()
                    ->select('o.id, o.code, o.sortOrder, a.code as attributeId')
                    ->from('PimCatalogBundle:AttributeOption', 'o')
                    ->innerJoin('o.attribute', 'a')
                    ->where('a.code=:attribute_code')
                    ->andWhere('o.code IN (:option_codes)')
                    ->setParameter('attribute_code', $code)
                    ->setParameter('option_codes', $optionCode)
                    ->getQuery()
                    ->getResult();
        
        if($results === null){
            return $results;
        }else{
            return !empty($results[0]) ? $results[0]: null;
            
        }
        
    }
    
    public function matchAttributeCodeInDb($code)
    {
        
        $results = $this->em->createQueryBuilder()
                    -> select('a.code as code')
                    -> from('PimCatalogBundle:Attribute', 'a')
                    -> where('a.code = :code')
                    -> setParameter('code', $code)
                    -> getQuery()->getResult();
        if($results){
            foreach($results as $result){
                if(!empty($result['code'])){
                    return $result['code'];
                }
            }
        }else{
            return null;
        }
    }

    public function findAttrTypeInDB($code)
    {
        $results = $this->em->createQueryBuilder()
                    -> select('a.type as type')
                    -> from('PimCatalogBundle:Attribute', 'a')
                    -> where('a.code = :code')
                    -> setParameter('code', $code)
                    -> getQuery()->getResult();
        if($results){
            foreach($results as $result){
                if(!empty($result['type'])){

                    return $result['type'];
                }
            }
        }else{

            return null;
        }
    }

    // get Attribute By Local and Scope
    public function getAttributeTypeLocaleAndScope($field)
    {
        $results = $this->em->createQueryBuilder()
                -> select('a.code, a.type, a.localizable as localizable, a.scopable as scopable, a.defaultMetricUnit as defaultMetricUnit, a.metricFamily as metricFamily')
                -> from('PimCatalogBundle:Attribute', 'a')
                -> where('a.code = :code')
                -> setParameter('code', $field)
                -> getQuery()->getResult();
        
       return $results;
    }
    
    public function searchOptionsValueByExternalId($externalId , $attributeCode )
    {   
        $option = NULL;
        $results = $this->em->createQueryBuilder()
                -> select('d.code as code')
                -> from('Magento2Bundle:DataMapping', 'd')
                -> where('d.externalId = :id')
                -> andWhere('d.entityType = :entity')
                -> andWhere('d.code LIKE :code')
                -> setParameters( [
                    'id' => $externalId,
                    'entity' => 'option',
                    'code' => '%' . addcslashes($attributeCode, '%_') . '%'
                ])
                -> getQuery()->getResult();
                 
        foreach($results as $result){
            $option = !empty($result['code']) ? explode("(", $result['code'])[0] : '';
            break;
        }
        
        return $option;
    }

    public function getMappingByEntity($entity, $jobInstance)
    {
        $apiUrl = $this->getApiUrl();
        
        $results = $this->em->createQueryBuilder()
                 -> select('d.code, d.relatedId')
                 -> from('Magento2Bundle:DataMapping', 'd')
                 -> where('d.entityType = :entity')
                 -> andWhere('d.jobInstanceId = :jobInstance')
                 -> andWhere('d.apiUrl = :apiUrl')
                 -> setParameters(
                     [
                        'entity' => $entity,
                        'jobInstance' => $jobInstance,
                        'apiUrl' => $apiUrl
                     ] )
                 -> getQuery()->getResult();
      
        return $results;
    }


    public function removeAllMappingByEntity($entity, $jobInstance)
    {
        $apiUrl = $this->getApiUrl();
        
        $results = $this->em->createQueryBuilder()
                 -> delete( )
                 -> from('Magento2Bundle:DataMapping', 'd')
                 -> where('d.entityType = :entity')
                 -> andWhere('d.jobInstanceId != :jobInstance')
                 -> setParameters(
                     [
                        'entity' => $entity,
                        'jobInstance' => $jobInstance
                        
                     ] )
                 -> getQuery()->getResult();
      
        return $results;
    }

    public function getMergeMappings()
    {
        // fetch attribute Mapping
        $attributeMappings = $this->getAttributeMappings();        

        //fetch other Mapping 
        $otherMapping = $this->getOtherMappings();
        $finalOtherMapping = [];
        if(!empty($otherMapping['custom_fields'])) {
            foreach($otherMapping['custom_fields'] as $key => $value) {
                $finalOtherMapping[$value] = $value;
            }
        }
        //merge attribute and other mapping
        $attributeMappings = array_merge($attributeMappings, $finalOtherMapping);

        return $attributeMappings;
    }

    public function getOptionLabelByAttributeCodeAndLocale($attribute, $code, $locale)
    {
        $attrCode = $attribute . '.' . $code;
        if(empty($this->attributeOptions[$attrCode])) {
            $this->attributeOptions[$attrCode] = $this->em->getRepository('PimCatalogBundle:AttributeOption')->findOneByIdentifier($attrCode);
        }

        $attributeOption = $this->attributeOptions[$attrCode];
        if($attributeOption) {
            $attributeOption->setLocale($locale);

            return $attributeOption->__toString() !== '[' . $code . ']' ? $attributeOption->__toString() : $code;
        }
    }

    public function getImageContentByPath($path)
    {
        return $this->container->get('akeneo_file_storage.file_storage.filesystem_provider')->getFilesystem('catalogStorage')
                ->read($path);
    }

    public function createFamilyVariant($content)
    {
        $normalizer = $this->container->get('pim_internal_api_serializer');
        $familyVariantFactory = $this->container->get('pim_catalog.factory.family_variant');
        $updater = $this->container->get('pim_catalog.updater.family_variant');
        $validator = $this->container->get('validator');
        $constraintViolationNormalizer = $this->container->get('pim_enrich.normalizer.violation');
        $saver = $this->container->get('pim_catalog.saver.family_variant');

        $familyVariant = $familyVariantFactory->create();
        $updater->update($familyVariant, $content);
        
        $violations = $validator->validate($familyVariant);

        $normalizedViolations = [];
        foreach ($violations as $violation) {
            $normalizedViolations[] = $constraintViolationNormalizer->normalize(
                $violation,
                'internal_api',
                ['family_variant' => $familyVariant]
            );
        }

        if (count($violations) > 0) {
            return new JsonResponse($normalizedViolations, 400);
        }
        
        $saver->save($familyVariant);

        return new JsonResponse(
            $normalizer->normalize(
                $familyVariant,
                'internal_api'
            )
        );
    }

    public function getApiUrl() 
    {
        $credentials = $this->getCredentials();
        $apiUrl = array_key_exists('hostName', $credentials) ? rtrim($credentials['hostName'] , '/') : '';
        $apiUrl = str_replace('https://', 'http://', $apiUrl );

        return $apiUrl;
    }

    public function checkExistProduct($code, $type)
    {
        if($type == 'configurable') {
            $entity = $this->container->get('pim_catalog.repository.product_model')->findOneByIdentifier($code);
            if(!empty($entity)) {
                return true;
            } else {
                return false;
            }
        } 
        if($type == 'simple') {
            $entity = $this->container->get('pim_catalog.repository.product')->findOneByIdentifier($code);
            if(!empty($entity)) {
                return true;
            } else {
                return false;
            }
        }
    }

    public function findFamilyVariantCode($productCode) 
    {
        $repo = $this->container->get('pim_catalog.repository.product_model');

        $result = $repo->createQueryBuilder('p')
                        ->select('f.code')  
                        ->leftJoin('p.familyVariant', 'f')
                        ->where('p.code = :code')
                        ->setParameter('code', $productCode)
                        ->getQuery()->getResult();
        if(isset($result[0])){
            return $result[0]['code'] ? $result[0]['code'] : null;
        }
    }

    public function updateFamilyAttributes($family, $attributes, $channelCode = "ecommerce") 
    {
        
        if($family) {
            $attributes_requirements = [];
            
            foreach($family->getAttributeRequirements() as $attribute_require) {
                $attributes_requirements[] = $attribute_require->getAttribute()->getCode(); 
            }
            
            $attributes_requirementsByChannel = [$channelCode => $attributes_requirements]; 
            
            $data = array(
                'code' => $family->getCode(),
                'attributes' => array_merge(
                                        $attributes,
                                        $family->getAttributeCodes()
                                    ),
                'attribute_as_label' => !empty($family->getAttributeAsLabel()) ? $family->getAttributeAsLabel()->getCode() : null,
                'attribute_as_image' => !empty($family->getAttributeAsImage()) ? $family->getAttributeAsImage()->getCode() : null,
                'attribute_requirements' => $attributes_requirementsByChannel,
            );

            $updater = $this->container->get('pim_catalog.updater.family');
            $saver = $this->container->get('pim_catalog.saver.family');
            
            try{
                $updater->update($family, $data);
                $saver->save($family);
            } catch(\Exception $e) {
                throw new \Exception($e->getMessage());
            }
            
        } else {
            throw new \Exception("Family Not Found");
        }

    }
}
