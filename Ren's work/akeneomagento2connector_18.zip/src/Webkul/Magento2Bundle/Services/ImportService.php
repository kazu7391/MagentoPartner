<?php

namespace Webkul\Magento2Bundle\Services;

class ImportService
{
    /* @var container */ 
    protected $container;

    protected $oauthClient;

    public function __construct($container) 
    {
        $this->container = $container;
    }
}