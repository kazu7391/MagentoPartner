"use strict";

define(
    [
        'underscore',
        'oro/translator',
        'pim/form',
        'magento2/template/configuration/tab/otherSettings',
        'oro/loading-mask',
        'pim/fetcher-registry',
        'pim/user-context',        
        'bootstrap.bootstrapswitch'
    ],
    function(
        _,
        __,
        BaseForm,
        template,
        LoadingMask,
        FetcherRegistry,
        UserContext,         
    ) {
        return BaseForm.extend({
            isGroup: true,
            label: __('magento2.otherSettings.tab'),
            template: _.template(template),
            code: 'magento2_connector_otherSettings',
            errors: [],
            events: {
                'change .AknFormContainer-otherSettings input': 'updateModel',
                'change .AknFormContainer-otherSettings select': 'updateModel',
                'click .AknFormContainer-otherSettings input': 'updateModel',

            },

            /**
             * {@inheritdoc}
             */
            configure: function () {
                this.listenTo(
                    this.getRoot(),
                    'pim_enrich:form:entity:bad_request',
                    this.setValidationErrors.bind(this)
                );

                this.listenTo(
                    this.getRoot(),
                    'pim_enrich:form:entity:pre_save',
                    this.resetValidationErrors.bind(this)
                );

                this.trigger('tab:register', {
                    code: this.code,
                    label: this.label
                });

                return BaseForm.prototype.configure.apply(this, arguments);
            },
            attributes: null,

            /**
             * {@inheritdoc}
             */
            render: function () {
                $('#container .AknButtonList[data-drop-zone="buttons"] div:nth-of-type(1)').show();
                var loadingMask = new LoadingMask();
                loadingMask.render().$el.appendTo(this.getRoot().$el).show();

                var attributes;
                if(this.attributes) {
                    attributes = this.attributes;
                } else {
                    attributes = FetcherRegistry.getFetcher('attribute').search({options: {'page': 1, 'limit': 10000 } });
                }
                var self = this;

                Promise.all([attributes]).then(function(values) {
                    self.attributes = values[0];
                    var otherSettings = typeof(self.getFormData()['otherSettings']) !== 'undefined' ? self.getFormData()['otherSettings'] : {};
                    self.$el.html(self.template({
                        settings: otherSettings,
                        attributes: self.attributes,
                        currentLocale: UserContext.get('uiLocale'),                        
                    }));

                    self.$('*[data-toggle="tooltip"]').tooltip();
                    self.$('.switch').bootstrapSwitch();
                    
                    loadingMask.hide().$el.remove();                    
                });

                this.delegateEvents();

                return BaseForm.prototype.render.apply(this, arguments);
            },

            /**
             * {@inheritdoc}
             */
            postRender: function () {
                this.$('.switch').bootstrapSwitch();
            },
            
            /**
             * Update model after value change
             *
             * @param {Event} event
             */
            updateModel: function (event) {
                var data = this.getFormData();
         
                var index = 'otherSettings';
                if(typeof(data[index]) === 'undefined' || !data[index] || typeof(data[index]) !== 'object' || data[index] instanceof Array) {
                    data[index] = {};
                }
                
                if( $(event.target).attr('name') == "metric_selection"){
                    var val = $(event.target).is(':checked');
                    if(val == true){
                        val = "true";
                    }else{
                        val = "false";
                    }
                    data[index][$(event.target).attr('name')] = val;    
                }else{
                    data[index][$(event.target).attr('name')] = event.target.value;
                }
                this.setData(data);
            },

            
            /**
             * Sets errors
             *
             * @param {Object} errors
             */
            setValidationErrors: function (errors) {
                this.errors = errors.response;
                this.render();
            },

            /**
             * Resets errors
             */
            resetValidationErrors: function () {
                this.errors = {};
                this.render();
            }
        });
    }
);