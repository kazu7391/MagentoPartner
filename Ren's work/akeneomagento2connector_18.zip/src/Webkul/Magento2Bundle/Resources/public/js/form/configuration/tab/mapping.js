"use strict";

define(
    [
        'underscore',
        'oro/translator',
        'pim/form',
        'magento2/template/configuration/tab/mapping',
        'pim/router',
        'oro/loading-mask',
        'pim/fetcher-registry',
        'pim/user-context',
        'pim/initselect2'
    ],
    function(
        _,
        __,
        BaseForm,
        template,
        router,
        LoadingMask,
        FetcherRegistry,
        UserContext,
        initSelect2
    ) {
        return BaseForm.extend({
            isGroup: true,
            label: __('magento2.attribute_mapping'),
            template: _.template(template),
            code: 'magento2_connector_mapping',
            events: {
                'change .AknFormContainer-Mappings input:not(".view-only")': 'updateModel',
                'change .AknFormContainer-Mappings select:not(".view-only")': 'updateModel',
                'click .field-add': 'addField', 
                'click .AknIconButton--remove.delete-row': 'removeField',
                'click .select-all': 'selectAll',            
                'click .remove-all': 'deselectAll',            
            },
            fields: null,
            attributes: null,
            /**
             * {@inheritdoc}
             */
            configure: function () {
                this.trigger('tab:register', {
                    code: this.code,
                    label: this.label
                });

                return BaseForm.prototype.configure.apply(this, arguments);
            },

            /**
             * {@inheritdoc}
             */
            render: function () {
                $('#container .AknButtonList[data-drop-zone="buttons"] div:nth-of-type(1)').show();
                var loadingMask = new LoadingMask();
                loadingMask.render().$el.appendTo(this.getRoot().$el).show();


                var fields;
                var attributes;
                if(this.fields && this.attributes) {
                    fields = this.fields;
                    attributes = this.attributes;
                } else {
                    fields = FetcherRegistry.getFetcher('magento-fields').fetchAll();
                    attributes = FetcherRegistry.getFetcher('attribute').search({options: {'page': 1, 'limit': 10000 } });
                }
                var self = this; 
                Promise.all([fields, attributes]).then(function(values) {
                    $('#container .AknButton--apply.save').show();
                    self.fields = values[0];
                    var formData = self.getFormData();  
                    self.addSelectedAttributes(self.getArrayValues(formData['mapping']));
                    
                    if(formData) {
                        var extraFields = self.generateExtraFields(self.fields, formData);
                        $.each(extraFields, function(key,field) {
                            self.fields.push(field); 
                        });
                    }
                    
                    self.attributes = self.sortByLabel(values[1]);
                    self.imageAttrs = self.sortImages(values[1], formData);

                    self.$el.html(self.template({
                        fields: self.fields,
                        attributes: self.attributes,
                        imageAttrs: self.imageAttrs,
                        model: formData,
                        mapping: formData['mapping'],
                        currentLocale: UserContext.get('uiLocale'),
                    }));

                    $('.select2').select2();

                    self.$('*[data-toggle="tooltip"]').tooltip();
                    loadingMask.hide().$el.remove();
                });

                this.delegateEvents();

                return BaseForm.prototype.render.apply(this, arguments);
            },

            generateExtraFields: function(fields, formData) {
                var extraFields = [];
                var fieldCodes = [];
                $.each(fields, function(key, value) {
                    fieldCodes.push(value.name);
                });

                if('undefined' !== typeof(formData['mapping']) && formData['mapping']) {
                    $.each(formData['mapping'], function(key, value) {
                        if(-1 === fieldCodes.indexOf(key)) {
                            extraFields.push({
                                    'name': key,
                                    'types': null,
                                    'dynamic': true
                            });
                        }
                    });

                }

                return extraFields;
                
            },
            imageAttrs: [],
            /**
             * Update model after value change
             *
             * @param {Event} event
             */
            updateModel: function (event) {
                var val;
                if($(event.target).hasClass('select2') && ($(event.target).hasClass('select2-container-multi') || $(event.target).attr('name') == 'images')) {
                    val = $(event.target).select2('data')
                    val = val.map(function(obj) { return obj.id });
                    
                } else {
                    val = $(event.target).val();
                }
                var data = this.getFormData();
                var wrapper = $(event.target).attr('data-wrapper') ? $(event.target).attr('data-wrapper') : 'mapping' ;
                if(typeof(data[wrapper]) === 'undefined' || !data[wrapper] || typeof(data[wrapper]) !== 'object' || data[wrapper] instanceof Array) {
                    data[wrapper] = {};
                }

                data[wrapper][$(event.target).attr('name')] = val;
                this.setData(data);
            },
            addField: function(e) {
                this.resetDynamicErrors(e);

                var field = $('#dynamic-filed-input');
                var val = field.val();
                if(val && this.reservedAttributes.indexOf(val.toLowerCase()) === -1 ) {
                    field.val('');
                    var newField = {
                                'name': val,
                                'types': null,
                                'dynamic': true
                            };
                    this.fields.push(newField);

                    this.render();
                } else {
                    this.addDynamicErrors(e);
                }
            },
            removeField: function(e) {
                var fieldId = $(e.target).attr('data-id');
                var fieldName = $(event.target).attr('data-name');
                this.fields.splice(fieldId, 1);

                var data = this.getFormData();
                if('undefined' !== typeof(data['mapping'])) {
                    delete data['mapping'][fieldName];
                }
                this.setData(data);

                this.render();                
            },
            deselectAll: function(e) {
                var target = $('#' + $(e.target).attr('data-for'));
                if(target) {
                    target.val([]);
                    target.trigger('change');
                }
            },
            selectAll: function(e) {
                var target = $('#' + $(e.target).attr('data-for'));
                if(target) {
                    var mappedFields = $('#mapped-fields select.attributeValue');
                    var mappedValues = [];
                    $.each(mappedFields, function(key, option) {
                        if(option.value) {
                            mappedValues.push(option.value);
                        }
                    });
                    var values = [];
                    $.each(target.find('option'), function(key, option) {
                        if(option.value && mappedValues.indexOf(option.value) === -1) {
                            values.push(option.value);
                        }
                    });

                    target.val(values);
                    target.trigger('change');
                }
            },
            getArrayValues: function(data) {
                var values = [];
                if(data) {
                    $.each(data, function(key, value) {
                        if(value) {
                            values.push(value);
                        }
                    });
                }

                return values;
            },
            selectedAttributes: [],
            
            addSelectedAttributes: function(values) {
                this.selectedAttributes = values;
            },
            resetDynamicErrors: function(e) {
                $(e.target).closest('.field-group').find('.AknFieldContainer-validationError').remove();
            },
            sortByLabel: function(data) {
                data.sort(function(a, b) {
                    var textA = typeof(a.labels[UserContext.get('uiLocale')]) !== 'undefined' && a.labels[UserContext.get('uiLocale')] ? a.labels[UserContext.get('uiLocale')].toUpperCase() : a.code.toUpperCase();
                    var textB = typeof(b.labels[UserContext.get('uiLocale')]) !== 'undefined' && b.labels[UserContext.get('uiLocale')] ? b.labels[UserContext.get('uiLocale')].toUpperCase() : b.code.toUpperCase();
                    return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
                });
                return data;
            },
            sortImages: function(data,  fields) {
                var imageData = [];
                var alreadyImages = (typeof(fields.otherMappings) !== 'undefined' && typeof(fields.otherMappings.images) !== 'undefined') ? fields.otherMappings.images : [];
                for(var i=0; i < data.length; i++) {
                    if(data[i].type === 'pim_catalog_image') {
                        imageData.push(data[i]);
                    }
                }
                imageData.sort(function(a, b) {
                    var textA = alreadyImages.indexOf(a.code);
                    var textB = alreadyImages.indexOf(b.code);
                    return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
                });
                return imageData;                
            },
            addDynamicErrors: function(e) {
                $(e.target).closest('.field-group').append('<span class="AknFieldContainer-validationError"><i class="icon-warning-sign"></i><span class="error-message">This value is not valid.</span></span>');
            },  
            reservedAttributes: ['sku', 'name', 'weight', 'price', 'description', 'short_description', 'quantity', 'meta_title', 'meta_keyword', 'meta_description', 'url_key', 'id', 'type_id', 'created_at', 'updated_at', 'attribute_set_id', 'category_ids'],
        });
    }
);
