"use strict";

define(
    [
        'underscore',
        'oro/translator',
        'pim/form',
        'magento2/template/configuration/tab/overview',
    ],
    function(
        _,
        __,
        BaseForm,
        template,
    ) {
        return BaseForm.extend({
            isGroup: true,
            label: __('magento2.overview'),
            template: _.template(template),
            code: 'magento2_connector_overview',
            // events: {
                // 'change .AknFormContainer-Mappings input': 'updateModel'
            // },

            /**
             * {@inheritdoc}
             */
            configure: function () {
                this.trigger('tab:register', {
                    code: this.code,
                    label: this.label
                });

                return BaseForm.prototype.configure.apply(this, arguments);
            },

            /**
             * {@inheritdoc}
             */
            render: function () {
                $('#container .AknButtonList[data-drop-zone="buttons"] div:nth-of-type(1)').hide();
                
                this.$el.html(this.template());

                // this.delegateEvents();

                return BaseForm.prototype.render.apply(this, arguments);
            },
        });
    }
);
