"use strict";

define(
    [
        'underscore',
        'oro/translator',
        'pim/form',
        'magento2/template/configuration/tab/storeMapping',
        'pim/fetcher-registry',
        'oro/loading-mask',
    ],
    function(
        _,
        __,
        BaseForm,
        template,
        FetcherRegistry,
        LoadingMask,                
    ) {
        return BaseForm.extend({
            isGroup: true,
            label: __('magento2.store_mapping'),
            template: _.template(template),
            code: 'magento2_connector_store_mapping',
            events: {
                'change select': 'updateModel',
            },
            currencies: null,

            /**
             * {@inheritdoc}
             */
            configure: function () {
                this.trigger('tab:register', {
                    code: this.code,
                    label: this.label
                });

                return BaseForm.prototype.configure.apply(this, arguments);
            },

            /**
             * {@inheritdoc}
             */
            render: function () {
                $('#container .AknButtonList[data-drop-zone="buttons"] div:nth-of-type(1)').show();
                var loadingMask = new LoadingMask();
                loadingMask.render().$el.appendTo(this.getRoot().$el).show();

                var currencies;
                if(this.currencies) {
                    currencies = this.currencies;
                } else {
                    currencies = FetcherRegistry.getFetcher('currency').search({options: {'page': 1, 'limit': 10000, 'activated': 1 } });
                }
                var self = this; 
                Promise.all([currencies]).then(function(values) {
                    self.currencies = values[0];
                    $('#container .AknButton--apply.save').show();
                    var storeViews = self.getFormData()['storeViews'];
                    try {
                        if(typeof(storeViews) !== 'object') {
                            var storeViews = JSON.parse(storeViews);
                        }
                    } catch(e) {
                        var storeViews = {};
                    }
                    
                    self.$el.html(self.template({
                        locales: self.getFormData()['locales'],
                        storeViews: storeViews,
                        storeMapping: self.getFormData()['storeMapping'],
                        currencies: self.currencies,
                    }));
                    loadingMask.hide().$el.remove();
                });

                this.delegateEvents();

                return BaseForm.prototype.render.apply(this, arguments);
            },

            /**
             * Update model after value change
             *
             * @param {Event} event
             */
            updateModel: function (event) {
                var data = this.getFormData();
                if(!data['storeMapping'])
                    data['storeMapping'] = {};

                if($(event.target).closest('.storeViewData')) {
                    var storeView = $(event.target).closest('.storeViewData').attr('data-storeView');
                    if(typeof(data['storeMapping'][storeView]) == 'undefined') {
                        data['storeMapping'][storeView] = {};
                    }
                    data['storeMapping'][storeView][$(event.target).attr('name')] = event.target.value;
                }

                this.setData(data);
            },
        });
    }
);
