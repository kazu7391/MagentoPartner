<?php

namespace Webkul\Magento2Bundle\JobParameters;

use Akeneo\Component\Batch\Job\JobInterface;
use Akeneo\Component\Batch\Job\JobParameters\ConstraintCollectionProviderInterface;
use Akeneo\Component\Batch\Job\JobParameters\DefaultValuesProviderInterface;
use Symfony\Component\Validator\Constraints\Collection;
use Symfony\Component\Validator\Constraints\Url;
use Symfony\Component\Validator\Constraints\Optional;
use Symfony\Component\Validator\Constraints\NotBlank;
use Pim\Component\Catalog\Query\Filter\Operators;
use Pim\Component\Connector\Validator\Constraints\FilterStructureLocale;
use Pim\Component\Connector\Validator\Constraints\FilterStructureAttribute;
use Pim\Component\Connector\Validator\Constraints\FilterData;
use Pim\Component\Catalog\Repository\ChannelRepositoryInterface;
use Pim\Component\Catalog\Repository\LocaleRepositoryInterface;
use Webkul\Magento2Bundle\Component\Validator\ValidCredentials;
use Symfony\Component\Validator\Constraints\Required;
use Webkul\Magento2Bundle\Services\Magento2Connector;

class Magento2Import implements
    ConstraintCollectionProviderInterface,
    DefaultValuesProviderInterface
{
    /** @var array */
    protected $supportedJobNames;

    /** @var ChannelRepositoryInterface */
    protected $channelRepository;

    /** @var LocaleRepositoryInterface */
    protected $localeRepository;

    /**
     * @param ChannelRepositoryInterface     $channelRepository
     * @param LocaleRepositoryInterface      $localeRepository
     * @param array                          $supportedJobNames
     */
    public function __construct(
        ChannelRepositoryInterface $channelRepository,
        LocaleRepositoryInterface $localeRepository,
        array $supportedJobNames
    ) {
        $this->channelRepository = $channelRepository;
        $this->localeRepository = $localeRepository;
        $this->supportedJobNames = $supportedJobNames;
    }

    /**
     * {@inheritdoc}
     */
    public function getDefaultValues()
    {
        $parameters = [
            'with_media' => true
            ];
        /* temporary ( remove this ) */ 
        $parameters['filePath'] = '/tmp/category.csv';

        $channels = $this->channelRepository->getFullChannels();
        $defaultChannelCode = (0 !== count($channels)) ? $channels[0]->getCode() : null;

        $localesCodes = $this->localeRepository->getActivatedLocaleCodes();
        $defaultLocaleCode = (0 !== count($localesCodes)) ? $localesCodes[0] : null;

        $parameters['filters'] = [
          
            'structure' => [
                'scope'   => $defaultChannelCode,
                'locales' => [$defaultLocaleCode],
                'locale' =>   $defaultLocaleCode,
            ],
        ];

        $parameters['with_media'] = true;
        $parameters['realTimeVersioning'] = false;
        $parameters['enabledComparison'] = false;
        $parameters['hostName'] = '';


        return $parameters;
    }

    /**
     * {@inheritdoc}
     */
    public function getConstraintCollection()
    {
        $constraintFields = [];
        $constraintFields['user_to_notify'] = new Optional();
        $constraintFields['product_only'] = new Optional();
        $constraintFields['with_media'] = new Optional();
        
        $constraintFields['filters'] = [
            // $this->filterData(),
            new Collection(
                [
                    'fields'           => [
                        'structure' => [
                            new FilterStructureLocale(['groups' => ['Default', 'DataFilters']]),
                            new Collection(
                                [
                                    'fields'             => [
                                        'locales'    => new Optional(), //[ new NotBlank(), new Count(1)]
                                        'locale'     => new NotBlank(),
                                        'currency'   => new NotBlank(),
                                        'scope'      => new NotBlank(),
                                        'attributes' => new FilterStructureAttribute(
                                            [
                                                'groups' => ['Default', 'DataFilters'],
                                            ]
                                        ),
                                    ],
                                    'allowMissingFields' => true,
                                ]
                            ),
                        ],
                    ],
                    'allowExtraFields' => true,
                ]
            ),
        ];        
        $constraintFields['hostName'] = [ new Url(), new ValidCredentials()];
        $constraintFields['consumerKey'] = [ new Optional() ];
        $constraintFields['consumerSecret'] = [ new Optional() ];     
        $constraintFields['authToken'] = [ new Optional() ];
        $constraintFields['authSecret'] = [ new Optional() ];     
        $constraintFields['storeMapping'] = [ new Required() ];
        $constraintFields['with_media'] = new Optional();
        $constraintFields['realTimeVersioning'] = new Optional();
        $constraintFields['enabledComparison'] = new Optional();
        $constraintFields['product_only'] = new Optional();

        return new Collection([
                            'fields' => $constraintFields,
                            'allowExtraFields' => true,
                            'allowMissingFields' => true,         
                        ]);
    }

    /**
     * {@inheritdoc}
    */
    public function supports(JobInterface $job)
    {
        return in_array($job->getName(), $this->supportedJobNames);
    }

    public function filterData()
    {
        if(class_exists('\Pim\Component\Connector\Validator\Constraints\FilterData')){
            return new \Pim\Component\Connector\Validator\Constraints\FilterData(['groups' => ['Default', 'DataFilters']]);
        }else{
            return new \Pim\Component\Connector\Validator\Constraints\ProductFilterData(['groups' => ['Default', 'DataFilters']]);
        }
    }
    
 
}
