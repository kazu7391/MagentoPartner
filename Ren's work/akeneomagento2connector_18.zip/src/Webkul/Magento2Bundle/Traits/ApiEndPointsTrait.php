<?php

namespace Webkul\Magento2Bundle\Traits;

/**
* trait used to getOAuthClient Api EndPoints
*/ 
trait ApiEndPointsTrait
{
    private $apiEndpoints = [
            'storeViews'          => '/rest/V1/store/storeViews',  
            'storeConfigs'        => '/rest/V1/store/storeConfigs',
            'product'             => '/rest/{_store}/V1/products/?searchCriteria=',
            'currency'            => '/rest/{_store}/V1/directory/currency',
            'getAttributeSets'    => '/rest/{_store}/V1/products/attribute-sets/sets/list?searchCriteria[pageSize]=50',
            'addAttributeSet'     => '/rest/{_store}/V1/products/attribute-sets',
            'updateAttributeSet'  => '/rest/{_store}/V1/products/attribute-sets/{attributeSetId}',
            'addToAttributeSet'   => '/rest/{_store}/V1/products/attribute-sets/attributes',
            'getAttributeSet'     => '/rest/{_store}/V1/products/attribute-sets/{attributeSetId}/attributes',
            'configurableOptions' => '/rest/{_store}/V1/configurable-products/{sku}/options/all',
            'addChild'            => '/rest/{_store}/V1/configurable-products/{sku}/child',
            'categories'          => '/rest/{_store}/V1/categories?searchCriteria=',
            'updateCategory'      => '/rest/{_store}/V1/categories/{category}',
            'attributes'          => '/rest/{_store}/V1/products/attributes?searchCriteria=',
            'getAttributes'       => '/rest/{_store}/V1/products/attributes/{attributeCode}',
            'updateAttributes'    => '/rest/{_store}/V1/products/attributes/{attributeCode}',
            'attributeOption'     => '/rest/{_store}/V1/products/attributes/{attributeCode}/options',
            'deleteAttributeOption'=> '/rest/{_store}/V1/products/attributes/{attributeCode}/options/{option}',
            'addAttributeGroup'   => '/rest/{_store}/V1/products/attribute-sets/groups',
            'getAttributeGroup'   => '/rest/{_store}/V1/products/attribute-sets/groups/list?searchCriteria=',
            'addCategoryToProduct' => '/rest/{_store}/V1/categories/{categoryId}/products',
            'getProduct'          => '/rest/{_store}/V1/products/{sku}',
            'addLinks'            => '/rest/{_store}/V1/products/{sku}/links',
        ];
}