<?php

namespace Webkul\Magento2Bundle\Controller\Rest;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\Url;
use Symfony\Component\Validator\Constraints\Optional;
use Webkul\Magento2Bundle\Entity;
use Symfony\Component\Form\FormError;
use Oro\Bundle\ConfigBundle\Entity\ConfigValue;
use Akeneo\Component\Batch\Model\JobInstance;

/**
 * Configuration rest controller in charge of the magento2 connector configuration managements
 */
class ConfigurationController extends Controller
{
    const SECTION = 'magento2_connector';

    const SECTION_STORE_MAPPING = 'magento2_store_mapping';
    const QUICK_EXPORT_CODE = 'magento2_product_quick_export';

    /**
     * Get the current configuration
     *
     *
     * @return JsonResponse
     */
    public function getAction()
    {
        $connectorService = $this->get('magento2.connector.service');
        $data = $connectorService->getCredentials();
        if($data["authSecret"] && $data["authToken"] && $data["consumerSecret"]) {
            $data["authSecret"] = $data["authToken"] = $data["consumerSecret"] = str_repeat("*", 20);
        }
        $data['mapping'] = $connectorService->getAttributeMappings();        
        $data['locales'] = $this->get('pim_catalog.repository.locale')->getActivatedLocalesQB()->getQuery()->getArrayResult();

        if($otherMapping = $connectorService->getOtherMappings()) {
            $data['otherMappings'] = $otherMapping;
        }
        if($otherSettings = $connectorService->getSettings()) {
            $data['otherSettings'] = $otherSettings; 
        }
        if($associationMapping = $connectorService->getSettings('magento2_association_mapping')) {
            $data['association'] = $associationMapping; 
        }

        return new JsonResponse($data);
    }

    /**
     * Set the current configuration
     *
     * @return JsonResponse
     */
    public function postAction(Request $request)
    {
        $data  = [];
        $request->request->remove('locales');        
        $params = $request->request->all();
        $em = $this->getDoctrine()->getManager();
        $connectorService = $this->get('magento2.connector.service');

        switch($request->attributes->get('tab')) {
            case 'mapping':
                $attributeData = !empty($params['mapping']) ? $params['mapping'] : null;
                if($attributeData) {
                    $connectorService->saveAttributeMappings($attributeData);
                }
                if(isset($params['otherMappings'])) {
                    $connectorService->saveOtherMappings($params['otherMappings']);
                }
                
                return new JsonResponse([]);
                break;

            case 'association':
                $associationData = !empty($params['association']) ? $params['association'] : null;
                if($associationData) {
                    $connectorService->saveSettings($associationData, "magento2_association_mapping");
                }
                return new JsonResponse([]);
                break;

            case 'storeMapping':
                $storeViews = !empty($params['storeViews']) ? json_decode($params['storeViews'], true) : [];
                $storeViewCodes = [];
                foreach($storeViews as $storeView) {
                    $storeViewCodes[] = $storeView['code'];
                }
                $mapData = !empty($params['storeMapping']) ? $params['storeMapping'] : null;
                foreach($mapData as $key => $mappingRow) {
                    if(!in_array($key, $storeViewCodes)) {
                        unset($mapData[$key]);
                    }
                }

                if($mapData) {
                    $repo = $em->getRepository('OroConfigBundle:ConfigValue');
                    $storeMapping = $repo->findOneBy([
                        'section' => self::SECTION_STORE_MAPPING,
                        'name' => 'storeMapping',
                        ]);

                    if(!$storeMapping) {
                        $storeMapping = new ConfigValue();
                        $storeMapping->setSection(self::SECTION_STORE_MAPPING);
                        $storeMapping->setName('storeMapping');
                    }
                    $storeMapping->setValue(json_encode($mapData) );
                    $em->persist($storeMapping);
                    $em->flush();
                }
                return new JsonResponse([]);
                break;
            case 'otherSettings':
                $tab = $request->attributes->get('tab');
                $data = !empty($params[$tab]) ? $params[$tab] : null;
                if($data) {
                    $connectorService->saveSettings($params[$tab]);                    
                }
                break;

            case 'credential':
            default:
                $form = $this->getConfigForm();
                if(!empty($params['hostName']) && !empty($params['consumerKey']) && $params['consumerSecret'] === str_repeat("*", 20) && $params['authToken'] === str_repeat("*", 20) && $params['authSecret'] === str_repeat("*", 20)) {
                    $data = $connectorService->getCredentials();
                    $params['consumerSecret'] = !empty($data["consumerSecret"]) ? $data["consumerSecret"] : '';
                    $params['authToken'] = !empty($data["authToken"]) ? $data["authToken"] : '';
                    $params['authSecret'] = !empty($data["authSecret"]) ? $data["authSecret"] : '';
                }
                $form->submit($params);
                $form->handleRequest($request);
                $storeViews = $connectorService->checkCredentialAndGetStoreViews($params);
                if(empty($storeViews)) {
                    $form->get('authToken')->addError(new FormError($this->get('translator')->trans('Invalid Credentials.') ));
                } else {
                    $params['storeViews'] = $storeViews;
                }
                $params['host'] = $request->getHost();
                
                if ($form->isSubmitted() && $form->isValid()) {
                    $this->checkAndSaveQuickJob();
                    
                    $repo = $em->getRepository('OroConfigBundle:ConfigValue');            
                    foreach($params as $key => $value) {
                        if(in_array($key, array_keys($this->getCredentialWithContraints())) || $key == 'storeViews' ) {
                            if(!is_array($value)) {
                                $value = strip_tags($value);

                                $configValue = $repo->findOneBy([
                                        'section' => self::SECTION, 'name' => $key
                                        ]);

                                if($configValue) {
                                    $configValue->setValue($value);
                                    $em->persist($configValue);
                                } else {
                                    $configValue = new ConfigValue();
                                    $configValue->setSection(self::SECTION);
                                    $configValue->setName($key);                                                
                                    $configValue->setValue($value);
                                    $em->persist($configValue);
                                }
                                $em->flush();
                            }
                        }
                    }
                    $connectorService->saveOtherSettings($params);
                } else {
                    return new JsonResponse($this->getFormErrors($form), RESPONSE::HTTP_BAD_REQUEST);
                }
        }
        
        return $this->getAction();
    }

    public function getDataAction() 
    {
        return new JsonResponse($this->mappingFields);
    }

    protected function checkAndSaveQuickJob()
    {
        $jobInstance = $this->get('pim_enrich.repository.job_instance')->findOneBy(['code' => self::QUICK_EXPORT_CODE]);
    
        if(!$jobInstance) {
            $em = $this->getDoctrine()->getManager();
            $jobInstance = new JobInstance();
            $jobInstance->setCode(self::QUICK_EXPORT_CODE);            
            $jobInstance->setJobName('magento2_quick_export');
            $jobInstance->setLabel('Magento 2 product quick export');
            $jobInstance->setConnector('Magento 2 Export Connector');            
            $jobInstance->setType('quick_export');
            $em->persist($jobInstance);
            $em->flush();
        }    
    }

    private function getConfigForm() 
    {
        $form = $this->createFormBuilder(null, [
                    'allow_extra_fields' => true,
                    'csrf_protection' => false
                ]);

        foreach($this->getCredentialWithContraints() as $field => $constraint) {
                $form->add($field, null, [
                    'constraints' => [
                        $constraint
                    ]
                ]);
        }

        return $form->getForm();
    }

    private function getFormErrors($form) 
    {
    	$errorContext = [];
        foreach ($form->getErrors(true) as $key => $error) {
            $errorContext[$error->getOrigin()->getName()] = $error->getMessage();
        }

        return $errorContext;
    }

    private function getCredentialWithContraints()
    {
        return [
            'hostName' => new Url(),
            'consumerKey' => new NotBlank(),
            'consumerSecret' => new NotBlank(),
            'authToken' => new NotBlank(),
            'authSecret' => new NotBlank(),
            'host' => new Optional(),
            
        ];
    }

    public function postStoreViewsandCheckCredentialAction(Request $request){
        $connectorService = $this->get('magento2.connector.service');
        $value = $request->request->all();
        $storeView;
        if(!empty($value['configuration'])){
            $storeView = $connectorService->checkCredentialAndGetStoreViews($value['configuration']);
        }
        
        if(!empty($storeView)){
            $response = new Response();
            $response->setContent($storeView);
            $response->headers->set('Content-Type', 'application/json');
            $response->setStatusCode(Response::HTTP_OK);
        }else{
            $response = new Response();
            $response->setContent($storeView . $this->get('translator')->trans('Invalid Credentials.'));
            $response->headers->set('Content-Type', 'application/json');
            $response->setStatusCode(Response::HTTP_NOT_FOUND);
        }
        
        return $response; 
    }
    private $mappingFields = [
        [
            'name' => 'sku',
            'label' => 'SKU',
            'placeholder' => '',
            'types' => [
                'pim_catalog_identifier',
                'pim_catalog_text',
                'pim_catalog_number',
            ],
            'tooltip' => 'supported attributes types: identifier, text, number (must be unique)',
        ],         
        [
            'name' => 'name',
            'label' => 'magento2_connector.attribute.name',
            'placeholder' => '',
            'types' => [
                'pim_catalog_text',
            ],
            'tooltip' => 'supported attributes types: text',
        ], 
        [
            'name' => 'weight',
            'label' => 'magento2_connector.attribute.weight',
            'placeholder' => '',
            'types' => [
                'pim_catalog_metric',
            ],
            'tooltip' => 'supported attributes types: metric',            
        ], 
        [
            'name' => 'price',
            'label' => 'magento2_connector.attribute.price',
            'placeholder' => '',
            'types' => [
                'pim_catalog_price_collection',
            ],
            'tooltip' => 'supported attributes types: price',            
        ],
        [
            'name' => 'description',
            'label' => 'magento2_connector.attribute.description',
            'placeholder' => '',
            'types' => [
                'pim_catalog_textarea',
            ],
            'tooltip' => 'supported attributes types: textarea',            
        ], 
        [
            'name' => 'short_description',
            'label' => 'magento2_connector.attribute.short_description',
            'placeholder' => '',
            'types' => [
                'pim_catalog_text',
                'pim_catalog_textarea',
            ],
            'tooltip' => 'supported attributes types: text, textarea',            
        ],
        [
            'name' => 'quantity',
            'label' => 'magento2_connector.attribute.quantity',
            'placeholder' => '',
            'types' => [
                'pim_catalog_number',
            ],
            'tooltip' => 'supported attributes types: number',            
        ],
        // [
        //     'name' => 'visibility',
        //     'label' => 'magento2_connector.attribute.visibility',
        //     'placeholder' => 'by default: visible on both search and catalog',
        //     'types' => [
            //     'pim_catalog_boolean',
            //  ],
        // ],
        [
            'name' => 'meta_title',
            'label' => 'magento2_connector.attribute.meta_title',
            'placeholder' => '',
            'types' => [
                'pim_catalog_text',
            ],
            'tooltip' => 'supported attributes types: text',
        ],
        [
            'name' => 'meta_keyword',
            'label' => 'magento2_connector.attribute.meta_keyword',
            'placeholder' => '',
            'types' => [
                'pim_catalog_text',
                'pim_catalog_textarea',
            ],
            'tooltip' => 'supported attributes types: text',
        ],
        [
            'name' => 'meta_description',
            'label' => 'magento2_connector.attribute.meta_description',
            'placeholder' => '',
            'types' => [
                'pim_catalog_text',
                'pim_catalog_textarea',
            ],
            'tooltip' => 'supported attributes types: text, textarea',            
        ],                             
        [
            'name' => 'url_key',
            'label' => 'magento2_connector.attribute.url_key',
            'placeholder' => '',
            'types' => [
                'pim_catalog_text',
            ],
            'tooltip' => 'supported attributes types: text',            
        ],
    ];    
}

