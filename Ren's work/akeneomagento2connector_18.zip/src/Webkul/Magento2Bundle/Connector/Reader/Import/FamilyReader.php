<?php

namespace Webkul\Magento2Bundle\Connector\Reader\Import;

use Akeneo\Component\Batch\Item\ItemReaderInterface;
use Akeneo\Component\Batch\Item\InitializableInterface;
use Akeneo\Component\Batch\Step\StepExecutionAwareInterface;
use Webkul\Magento2Bundle\Services\Magento2Connector;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Pim\Bundle\EnrichBundle\Controller\Rest\FamilyController;
use Akeneo\Component\Batch\Item\DataInvalidItem;
use Akeneo\Component\Batch\Item\FileInvalidItem;
use Akeneo\Component\Batch\Item\FlushableInterface;
use Akeneo\Component\Batch\Item\InvalidItemException;
use Akeneo\Component\Batch\Model\StepExecution;
use Webkul\Magento2Bundle\Component\OAuthClient;
use Webkul\Magento2Bundle\Traits\DataMappingTrait;
use Webkul\Magento2Bundle\Connector\Reader\Import\BaseReader;
/**
 * import attribute-sets from from Magento 2
 *
 * @author    webkul <support@webkul.com>
 * @copyright 2010-18 Webkul (http://store.webkul.com/license.html)
 */
class FamilyReader extends BaseReader implements ItemReaderInterface, StepExecutionAwareInterface, InitializableInterface
{
    use DataMappingTrait;

    private $familyObject;

    protected $locale;

    protected $jsonHeaders = ['Content-Type' => 'application/json', 'Accept' => 'application/json'];

    protected $itemIterator;

    protected $storeMapping;

    protected $identifierAttributeCode;

    protected $items;

    protected $firstRead;

    protected $channel;

    protected $attributeRequired;

    const AKENEO_ENTITY_NAME = 'family';

    /**
     * @param Magento2Connector     $connectorService
     */
    public function __construct (
        Magento2Connector $connectorService,
        \Doctrine\ORM\EntityManager $em,
        FamilyController $familyObject
    ) {
        parent::__construct($connectorService, $em);
        $this->familyObject = $familyObject;
    }

    /**
     * {@inheritdoc}
     */
    public function initialize()
    {
        $credentials = $this->connectorService->getCredentials();
        if(!$this->oauthClient) {
            $this->oauthClient = new OAuthClient($credentials['authToken'], $credentials['hostName']);
        }

        $this->identifierAttributeCode = $this->connectorService->getIdentifierAttributeCode();
        $filters = $this->stepExecution->getJobParameters()->get('filters');
        $this->locale = !empty($filters['structure']['locale']) ? $filters['structure']['locale'] : (!empty($filters['structure']['locales'][0]) ? $filters['structure']['locales'][0]:'');
        $this->storeMapping = $this->connectorService->getStoreMapping();
        
        $this->channel = !empty($filters['structure']['scope']) ? $filters['structure']['scope'] : '';

        $families = $this->getAttributeSets();
        $items = [];
            if(!empty($families['items'])) {
                $items = $this->formatData($families['items']);
            }
            $this->items = $items; 
            $this->firstRead = false;
    }


    public function read()
    {

        if( $this->itemIterator === null && $this->firstRead === false ) {
            $this->itemIterator = new \ArrayIterator($this->items);
            $this->firstRead = true;
        }

        $item = $this->itemIterator->current();

        if($item !== null) {
            $this->stepExecution->incrementSummaryInfo('read');
            $this->itemIterator->next();
        }
        
        return  $item;

    }

    protected function formatData($attributeSets)
    {
        $results = [];
        foreach($attributeSets as $attributeSet) {
            $familyCode = $this->connectorService->convertToCode($attributeSet['attribute_set_name']);
            $repo = $this->em->getRepository('PimCatalogBundle:Family');
            $family = $repo->findOneByIdentifier($familyCode);
            $attribute_requirements = [];
            $attributesByFamily = [];
            if($family){
                $repo2 = $this->em->getRepository('PimCatalogBundle:Locale');
                $activeLocales = $repo2->getActivatedLocales();
                
                foreach($activeLocales as $activeLocale){
                    $locale = $activeLocale->getCode();
                    $locales[$locale] = $locale ? $family->setLocale($locale)->getLabel(): $family->setLocale('en_US')->getLabel();
                }
                
                $attributeRequirements = $family->getAttributeRequirements();
                foreach($attributeRequirements as $attributeRequirement){
                    $channel = $attributeRequirement->getChannel()->getCode();
                    if(!empty($channel)){
                        $attribute_requirements[$channel] = [$attributeRequirement->getAttribute()->getCode()];
                    }
                }
                
                $attributesByFamily = $family->getAttributeCodes();
            }
            
            $addAttributesinFamily = [];
            $optionName= [];

            $otherMapping = $this->connectorService->getOtherMappings();
            //add image field
            $finalOtherMapping = [];
            if(!empty($otherMapping['images'])) {
                foreach($otherMapping['images'] as $key => $value) {
                    $finalOtherMapping[$value] = $value;
                }
            }
            $imageAttributesCodes = [];
            foreach($finalOtherMapping as $key => $attributes){
                $imageAttributesCodes[] = $attributes;
            }
            $this->attributeRequired = [];
            $attributesCodes = $this->getAttributesByAttributeSetId($attributeSet['attribute_set_id']);

            if($this->identifierAttributeCode) {
                $attributesCodes[] = $this->identifierAttributeCode;
            }
            if(!empty($otherMapping['images'][0])) {
                $attributesCodes[] =  $otherMapping['images'][0];
            }  

            if($attributesByFamily){
               $attributesCodes = array_unique(array_merge($attributesCodes, $imageAttributesCodes, $attributesByFamily));
            }
            $channel = !empty($channel) ? $channel : $this->channel;
            
            if(empty($attribute_requirements[$this->channel])) {
                $attribute_requirements = [$this->channel=> []];
            }
            $attribute_requirements[$this->channel] = array_merge($attribute_requirements[$this->channel], $this->attributeRequired); 
            
            $result = [
                'code' => !empty($family) ? $family->getCode() : $familyCode,
                'attribute_as_image' => !empty($otherMapping['images'][0]) ? $otherMapping['images'][0] :'',
                'attribute_as_label' => $this->identifierAttributeCode,
                'attributes' => $attributesCodes,
                'attribute_requirements' => $attribute_requirements
            ];
            
            //set locale 
            $locale = '';
            foreach($this->storeMapping as $storeCode => $value) {
                if($value['locale']){
                    $locale = $value['locale'];
                    break;
                }else{
                    continue;
                }
            }
            $locale = $locale ? $locale : $this->locale; 
            if(empty($locale)){
                $this->stepExecution->addWarning("Store or Job Locale Not found" , [] , new DataInvalidItem(['locale' => $locale, 'code' => $code ]) );
            }

            $result['labels'][$locale] = $attributeSet['attribute_set_name'];
            
            // Add to Mapping in Database 
            $externalId = !empty($attributeSet['attribute_set_id']) ? $attributeSet['attribute_set_id'] : null;
            $relatedId = !empty($attributeSet['entity_type_id']) ? $attributeSet['entity_type_id'] : null;
            $code = $result['code'];
            if($code && $externalId){
                $mapping = $this->addMappingByCode($code, $externalId, $relatedId, $this::AKENEO_ENTITY_NAME);
            }
            
            $results[] = $result;
        }

        return $results;
    }

    protected function filterAttributes($attributes)
    {
        $results = [];
        foreach($attributes as $key => $attribute) {
            if(!empty($attribute['is_user_defined']) && isset($attribute['frontend_input']) && in_array($attribute['frontend_input'], $this->attributeTypes) ) {
                $results[] = $attribute['attribute_code']; 
            }
        }
        
        return $results;
    }

    private function getAttributeSets()
    {
        $url = $this->oauthClient->getApiUrlByEndpoint('getAttributeSets');
        $url = str_replace('[pageSize]=50', '[pageSize]=500' , $url);
        $method = 'GET';
        
        return $this->fetchApiByUrlAndMethod($url, $method);
    }

    private function getAttributeByAttributeSet($attributeSetId)
    {
        $url = $this->oauthClient->getApiUrlByEndpoint('getAttributeSet');
        $url = str_replace('{attributeSetId}', $attributeSetId, $url);
        $method = 'GET';
        
        return $this->fetchApiByUrlAndMethod($url, $method);
    }

    private function fetchApiByUrlAndMethod($url, $method)
    {
        try {
            $this->oauthClient->fetch($url, null, $method, $this->jsonHeaders );
            $results = json_decode($this->oauthClient->getLastResponse(), true);
            return $results;
        } catch(\Exception $e) {
            $lastResponse = json_decode($this->oauthClient->getLastResponse(), true);
            $responseInfo = $this->oauthClient->getLastResponseInfo();
            foreach(array_keys($responseInfo) as $key ) {
                if(trim($key) == 'http_code') {
                    $lastResponse['http_code'] = $responseInfo[$key];
                    break;
                }
            }

            $error = ['error' => $lastResponse ];

            return $error;
        }
    }

    protected function getAttributesByAttributeSetId($attributeSetId) 
    {
        $url = $this->oauthClient->getApiUrlByEndpoint('getAttributeSet');
        $url = str_replace('{attributeSetId}', $attributeSetId , $url);
        $method = 'GET';
        $attributesCode = [];
        $attributes = $this->fetchApiByUrlAndMethod($url, $method);
        foreach($attributes as $key => $attribute) {
            if(!$attribute['is_user_defined']) {
                if(!in_array($attribute['attribute_code'], $this->systemAttribute )) {
                    continue;
                }
            }
            $mapping = $this->connectorService->getAttributeByCode($attribute['attribute_code']);
            if($mapping) {
                if($attribute['is_required'] === true) {
                    $this->attributeRequired[] = $attribute['attribute_code'];
                }
                $attributesCode[] = $attribute['attribute_code'];
            }
        }
        
        return $attributesCode;
    }


          
}
