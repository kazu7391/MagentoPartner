<?php

namespace Webkul\Magento2Bundle\Connector\Reader\Import;

use Akeneo\Component\Batch\Item\ItemReaderInterface;
use Akeneo\Component\Batch\Item\InitializableInterface;
use Akeneo\Component\Batch\Step\StepExecutionAwareInterface;
use Akeneo\Component\Batch\Item\FileInvalidItem;
use Akeneo\Component\Batch\Item\FlushableInterface;
use Akeneo\Component\Batch\Item\InvalidItemException;
use Akeneo\Component\Batch\Model\StepExecution;
use Webkul\Magento2Bundle\Component\OAuthClient;
use Webkul\Magento2Bundle\Services\Magento2Connector;
use Pim\Bundle\EnrichBundle\Controller\Rest\FamilyVariantController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Webkul\Magento2Bundle\Traits\DataMappingTrait;
use Webkul\Magento2Bundle\Connector\Reader\Import\BaseReader;
use Akeneo\Component\FileStorage\File\FileStorerInterface;
use Akeneo\Component\FileStorage\Repository\FileInfoRepositoryInterface;
use Pim\Component\Catalog\FileStorage;
use Pim\Bundle\EnrichBundle\Controller\FileController;
use Akeneo\Component\Batch\Item\DataInvalidItem;
/**
 * import products_model from Magento 2
 *
 * @author    webkul <support@webkul.com>
 * @copyright 2010-18 Webkul (http://store.webkul.com/license.html)
 */
class ProductModelReader extends BaseReader implements ItemReaderInterface, StepExecutionAwareInterface, InitializableInterface
{
    use DataMappingTrait;

    /** @var ImportService */
    protected $connectorService;

    /** @var StepExecution */
    protected $stepExecution;

    protected $locale;

    protected $scope;

    protected $oauthClient;

    protected $jsonHeaders = ['Content-Type' => 'application/json', 'Accept' => 'application/json'];

    protected $itemIterator;

    protected $storeCode;

    private $firstRead;

    private $items;

    private $attributeSets;

    private $family;

    private $familyVariantObject;

    protected $familyVariantCodes ;

    const AKENEO_ENTITY_NAME = 'product';

    /** @var FileStorerInterface */
    protected $storer;

    /** @var FileInfoRepositoryInterface */
    protected $fileInfoRepository;

    protected $uploadDir;

    protected $currentPage;

    public function __construct (
        Magento2Connector $connectorService,
        \Doctrine\ORM\EntityManager $em,
        FileStorerInterface $storer,
        FileInfoRepositoryInterface $fileInfoRepository,
        $uploadDir,
        FamilyVariantController $familyVariantObject
    ) { 
        parent::__construct($connectorService, $em);
        $this->storer = $storer;
        $this->fileInfoRepository = $fileInfoRepository;
        $this->uploadDir = $uploadDir;
        $this->familyVariantObject = $familyVariantObject;
    }

    public function initialize()
    { 
        $credentials = $this->connectorService->getCredentials();
        if(!$this->oauthClient) {
            $this->oauthClient = new OAuthClient($credentials['authToken'], $credentials['hostName']);
        }
        
        $filters = $this->stepExecution->getJobParameters()->get('filters');
        
        $this->locale = !empty($filters['structure']['locale']) ? $filters['structure']['locale'] : (!empty($filters['structure']['locales'][0]) ? $filters['structure']['locales'][0]:'');
        $this->scope = !empty($filters['structure']['scope']) ? $filters['structure']['scope'] : 'ecommerce';
        $storeMapping = $this->connectorService->getStoreMapping();    
        foreach($storeMapping as $storeCode => $storeData) {
            if($storeData['locale'] == $this->locale) {
                $this->storeCode = $storeCode;
                break; 
            }
        }
        
        $this->currentPage = 1; 
        $items = [];
        $productModels = $this->getProductModels($this->currentPage);
        if(!empty($productModels['items'])) {
            $items = $this->formatData($productModels['items']);
        }
        
        $this->items = $items;
        $this->firstRead = false;
    }

    /**
     * {@inheritdoc}
     */
    public function read()
    {
        if($this->itemIterator === null && $this->firstRead === false) {
            $this->itemIterator = new \ArrayIterator($this->items);
            $this->firstRead = true;
        }

        $item = $this->itemIterator->current();

        if($item !== null) {
            $this->stepExecution->incrementSummaryInfo('read');
            $this->itemIterator->next();
        } else {
            $this->currentPage++;
            $productModels = $this->getProductModels($this->currentPage);
            if(!empty($productModels['items'] )) {
                $this->items = $this->formatData($productModels['items']);
                $this->itemIterator = new \ArrayIterator($this->items);
                $item = $this->itemIterator->current();
                if($item !== null) {
                    $this->stepExecution->incrementSummaryInfo('read');
                    $this->itemIterator->next();
                }
            }
        }
        
        return  $item;
    }

    protected function getProductModels($currentPage , $pageSize = 10)
    {
        $url = $this->oauthClient->getApiUrlByEndpoint('product', $this->storeCode);
        $url = strstr($url, '?', true) . '?searchCriteria[filterGroups][0][filters][0][field]=type_id&searchCriteria[filterGroups][0][filters][0][value]=configurable&searchCriteria[pageSize]='.$pageSize.'&searchCriteria[currentPage]=' . $currentPage;
        $method = 'GET';
        
        try {
            $this->oauthClient->fetch($url, null, $method, $this->jsonHeaders );
            $results = json_decode($this->oauthClient->getLastResponse(), true);
            if(!empty($results['total_count'])) {
                if($currentPage * $pageSize <= $results['total_count']) {
                    
                    return $results;

                } else {
                    $restPage = (($currentPage * $pageSize) - $results['total_count']);
                    if($restPage <  $pageSize) {
        
                        return $results;

                    } else {
                        
                        return [];
                    }
                }    
            }
        } catch(\Exception $e) {
            $lastResponse = json_decode($this->oauthClient->getLastResponse(), true);
            $responseInfo = $this->oauthClient->getLastResponseInfo();
            foreach(array_keys($responseInfo) as $key ) {
                if(trim($key) == 'http_code') {
                    $lastResponse['http_code'] = $responseInfo[$key];
                    break;
                }
            }
            $error = ['error' => $lastResponse ];

            return $error;
        }
        
        return [];
    }

    protected function formatData($productModels)
    {
        $results = []; 
        foreach($productModels as $index => $productModel) {
         
            if(empty($productModel['sku'])) {
                continue;
            }
            $productSKU = $productModel['sku'];
            $productModel = $this->getProductBySKU($productModel['sku'], $this->storeCode);
            if(isset($productModel['error'])) {
                $this->stepExecution->addWarning("Error: to fetch product from API,  SKU :  $productSKU", [], new DataInvalidItem(["error" => $productModel, 'SKU' => $productSKU]));
                continue;
            }
            $code = $this->connectorService->convertToCode($productModel['sku']);
            $familyVariant = $this->connectorService->findFamilyVariantCode($code) ? : $this->getFamilyVariant($productModel); 
                        
            $result = [
                'code'           => $code,
                'categories'     => !empty($productModel['custom_attributes']) ? $this->getCategories($productModel['custom_attributes']) : [],    
                'family_variant' => $familyVariant, 
                'values'         => $this->getValues($productModel),
            ];
            
            
            //mapping configrable product variant links in database
            $this->addProductLinks($productModel);
            $mappedAttributes = $this->connectorService->getAttributeMappings();
            foreach($mappedAttributes as $magentoAttr => $akeneoAttr) {
                $attribute = $this->getAttributeByCode($akeneoAttr);
                $attrIndex = $akeneoAttr;
                $attrIndex .= '-' . $this->locale;
            }
            
            // Add to Mapping in Database 
            $externalId = !empty($productModel['id']) ? $productModel['id'] : null;
            // $relatedId = !empty($productModel['attribute_set_id']) ? $productModel['attribute_set_id'] : null;
            $relatedId = $familyVariant;
            $code = $result['code'];
            if($code && $externalId){
                $mapping = $this->addMappingByCode($code, $externalId, $relatedId, $this::AKENEO_ENTITY_NAME);
            }

            $results[] = $result;
        }
           
        return $results;
    }

    protected $attributes = [];

    protected function getAttributeByCode($attrCode)
    {
        if(!array_key_exists($attrCode, $this->attributes)) {
            $this->attributes[$attrCode] = $this->connectorService->getAttributeByCode($attrCode);
        }

        return $this->attributes[$attrCode];
    }

     

    protected function getattributeSets()
    {
        $url = $this->oauthClient->getApiUrlByEndpoint('getAttributeSets');
        $method = 'GET';

        try{
            $this->oauthClient->fetch($url, null, $method, $this->jsonHeaders );
            $results = json_decode($this->oauthClient->getLastResponse(), true);

            if(!empty($results['items'])){
                
                return $results['items'];
            }else{

                return [];
            }
            
        }catch(Exception $e){
            return [];
        }
    }
    
    protected function getFamilyVariant($productModel)
    {

        $sku = !empty($productModel['sku']) ? $productModel['sku'] : null;
        $attribute_set_id = !empty($productModel['attribute_set_id']) ?  $productModel['attribute_set_id'] : null;
        $family = NULL;
        $code = NULL;
        //add family variant in family
        $url = $this->oauthClient->getApiUrlByEndpoint('getProduct');
        $url = str_replace('{sku}', urlencode($sku), $url);
        $method = 'GET';
        
        try {
            $this->oauthClient->fetch($url, null, $method, $this->jsonHeaders );
            $results = json_decode($this->oauthClient->getLastResponse(), true);
            $attributes = [];
            if(!empty($results['extension_attributes']['configurable_product_options'])) {
                $options = $results['extension_attributes']['configurable_product_options'];
                foreach($options as $option){
                    //  $optionCode  = $this->connectorService->findCodeByExternalId($option['attribute_id'], 'attribute');
                    $optionCode = $this->getOptionCodeByAttributeId($option['attribute_id']);
                     if(!empty($optionCode)) {
                        $attributes[]  = $this->connectorService->matchAttributeCodeInDb($optionCode); #? : $optionCode;
                     }
                }
                
                //fetch attribute set
                $attribute_set_id = !empty($results['attribute_set_id']) ? $results['attribute_set_id'] : null;
                $url = $this->oauthClient->getApiUrlByEndpoint('addAttributeSet');
                $url = $url . '/' . $attribute_set_id;
                $method = 'GET';
                
                $this->oauthClient->fetch($url, null, $method, $this->jsonHeaders );
                $results = json_decode($this->oauthClient->getLastResponse(), true);
                
                $family = !empty($results['attribute_set_name']) ? $this->connectorService->getFamilyByCode($results['attribute_set_name']) : null;
                //add variant attributes in family as per mapping
                $attributeMappings = $this->connectorService->getAttributeMappings();
                foreach($this->variantAttributes as $attribute) {
                    if( in_array($attribute, array_keys($attributeMappings)) ) {
                        $variantAttributes[] = $attributeMappings[$attribute];
                    }
                }
                $variantAttributes = array_unique(array_merge($variantAttributes , $attributes));
                if($family) {
                    $familyCode = $family->getCode();
                    $restAttributes = array_diff($variantAttributes , $family->getAttributeCodes());
                    //if attributes are not present in family 
                    if($restAttributes) {    
                        $this->connectorService->updateFamilyAttributes($family, $restAttributes, $this->scope );
                    }

                }else{
                    throw new \Exception($results['attribute_set_name']." family is not imported");
                } 
                

                $code = preg_replace("/[^a-zA-Z]/", "", json_encode($attributes)).'_'.$familyCode;
                
                $label = preg_replace("/[^a-zA-Z]/", "", json_encode($attributes));
                
                
                $familyVariantMapping = $this->connectorService->getFamilyVariantByIdentifier($code);
                
                if(empty($familyVariantMapping)) {
                    $content = [
                        'labels' =>  array(
                            $this->locale => $label,
                        ),
                        'variant_attribute_sets' => [
                            array(
                                'level' => 1,
                                'axes' => is_array($attributes) ? $attributes : array($attributes),
                                'attributes' => $variantAttributes ? $variantAttributes : [],                                                
                                ) 
                        ],
                        'code' => $code,
                        'family' => $familyCode,
                    ]; 
                    
                    $response = $this->connectorService->createFamilyVariant($content);
                    $status = $response->getStatusCode();
                    if($status === Response::HTTP_BAD_REQUEST) {
                        $response = ($this->familyVariantObject->getAction($code));
                        throw new \Exception($response);
                    } 
                } 
            }
        } catch(\Exception $e) {
            throw new \Exception($e->getMessage());
        }

        return $code;
    }

    protected function addProductLinks($productModel)
    {
        //Add configurable product links mapping  for product variant
        $url = $this->oauthClient->getApiUrlByEndpoint('getProduct');
        $url = str_replace('{sku}', urlencode($productModel['sku']), $url);
        $method = 'GET';
        $attributesOptions = [];
        $product = $this->fetchApiByUrlAndMethod($url, $method);
        if(isset($productModel['error'])) {
            $this->stepExecution->addWarning('Error: to fetch product from API ', [], new DataInvalidItem(["error" => $productModel, 'SKU' => $productSKU]));
            return ;
        }
        $productLinks = !empty($product['extension_attributes']['configurable_product_links']) ? $product['extension_attributes']['configurable_product_links'] : '';
        if( !empty($product['extension_attributes']['configurable_product_options']) ){
            $options = $product['extension_attributes']['configurable_product_options'];
            
            foreach($options as $option){
                $optionCode = $this->getOptionCodeByAttributeId($option['attribute_id']);
                if(!empty($optionCode)) {
                $attributesOptions[] = $optionCode;
                }
            }
        }
        $externalId = !empty($product['id']) ? $product['id'] : null;
        $relatedId = json_encode(
            [
                "configurable_product_links" => $productLinks ,
                "configurable_product_options" => $attributesOptions
            ]
        );
        
        $code =  $this->connectorService->convertToCode($product['sku']);
            if($code && $externalId){
                //remove the previous mapping 
                $mapping = $this->connectorService->removeAllMappingByEntity('product_links', $this->stepExecution->getJobExecution()->getId());
                //add the new mapping
                $mapping = $this->addMappingByCode($code, $externalId, $relatedId, 'product_links');
            }

    }
 

     
    private function getAttributeByAttributeSet($attributeSetId)
    {
        $url = $this->oauthClient->getApiUrlByEndpoint('getAttributeSet');
        $url = str_replace('{attributeSetId}', $attributeSetId, $url);
        $method = 'GET';
        
        return $this->fetchApiByUrlAndMethod($url, $method);
    }

    private function fetchApiByUrlAndMethod($url, $method)
    {
        try {
            $this->oauthClient->fetch($url, null, $method, $this->jsonHeaders );
            $results = json_decode($this->oauthClient->getLastResponse(), true);
            return $results;
        } catch(\Exception $e) {
            $lastResponse = json_decode($this->oauthClient->getLastResponse(), true);
            $responseInfo = $this->oauthClient->getLastResponseInfo();
            foreach(array_keys($responseInfo) as $key ) {
                if(trim($key) == 'http_code') {
                    $lastResponse['http_code'] = $responseInfo[$key];
                    break;
                }
            }

            $error = ['error' => $lastResponse ];

            return $error;
        }
    }

    protected function filterAttributes($attributes)
    {
        $results = [];
        foreach($attributes as $key => $attribute) {
            if(!empty($attribute['is_user_defined']) && isset($attribute['frontend_input']) && in_array($attribute['frontend_input'], $this->attributeTypes) ) {
                $results[] = $attribute['attribute_code']; 
            }
        }

        return $results;
    }

  
    protected $variantAttributes = [
        'quantity',
        'weight',
        'quantity_and_stock_status',
        'weight',
        'price',
        'meta_title',
        'meta_keyword',
        'meta_description',
    ];
    
    protected function getOptionCodeByAttributeId($attributeId) 
    {
        $attribute_set_id = !empty($attributeId) ? $attributeId : null;
        $url = $this->oauthClient->getApiUrlByEndpoint('getAttributes');
        $url = str_replace('{attributeCode}', $attributeId, $url);
        $method = 'GET';
        $this->oauthClient->fetch($url, null, $method, $this->jsonHeaders );
        $results = json_decode($this->oauthClient->getLastResponse(), true);
        if(!empty($results['attribute_code'])){
            $code = $results['attribute_code'];
        }else{
            $code = '';
        }

        return $code;

    }

}
