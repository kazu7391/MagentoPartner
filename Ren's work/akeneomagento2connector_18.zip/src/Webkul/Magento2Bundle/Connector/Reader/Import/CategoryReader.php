<?php

namespace Webkul\Magento2Bundle\Connector\Reader\Import;

use Akeneo\Component\Batch\Item\InitializableInterface;
use Akeneo\Component\Batch\Step\StepExecutionAwareInterface;
use Akeneo\Component\Batch\Item\FileInvalidItem;
use Akeneo\Component\Batch\Item\FlushableInterface;
use Akeneo\Component\Batch\Item\InvalidItemException;
use Akeneo\Component\Batch\Item\ItemReaderInterface;
use Akeneo\Component\Batch\Model\StepExecution;
use Webkul\Magento2Bundle\Component\OAuthClient;
use Akeneo\Component\Batch\Item\DataInvalidItem;
use Webkul\Magento2Bundle\Traits\DataMappingTrait;
use Webkul\Magento2Bundle\Connector\Reader\Import\BaseReader;
/**
 * import category reader from Magento 2 
 *
 * @author    webkul <support@webkul.com>
 * @copyright 2010-18 Webkul (http://store.webkul.com/license.html)
 */
class CategoryReader extends BaseReader implements ItemReaderInterface,  StepExecutionAwareInterface , InitializableInterface
{
    use DataMappingTrait;

    protected $rootCategoryCode;

    protected $locale;

    protected $jsonHeaders = ['Content-Type' => 'application/json', 'Accept' => 'application/json'];

    protected $itemIterator;

    protected $storeMapping;

    protected $categories;

    protected $firstRead;

    protected $categoryCode; 

    const AKENEO_ENTITY_NAME = 'category';


    public function initialize()
    {
        $this->credentials = $this->connectorService->getCredentials();
        if(!$this->oauthClient) {
            $this->oauthClient = new OAuthClient($this->credentials['authToken'], $this->credentials['hostName']);
        }
        
        $filters = $this->stepExecution->getJobParameters()->get('filters');
        $channelCode = !empty($filters['structure']['scope']) ? $filters['structure']['scope'] : '';
        $channel = $channelCode ? $this->connectorService->findChannelByIdentifier($channelCode) : null;
        $rootCategory = $channel && $channel->getCategory() ? $channel->getCategory() : null; 
        $this->rootCategoryCode = $rootCategory ? $rootCategory->getCode() : null;
        $this->locale = !empty($filters['structure']['locale']) ? $filters['structure']['locale'] : !empty($filters['structure']['locales'][0]) ? $filters['structure']['locales'][0] : '';

        $this->storeMapping = $this->connectorService->getStoreMapping();
        $items = [];
        $counter = 1;
        $this->categoryCode = [];
        
        foreach($this->storeMapping as $storeCode => $storeData) {
            $locale = !empty($storeData['locale']) ? $storeData['locale'] : $this->locale;
            $categories = $this->getCategories($storeCode);
            if(!empty($categories)){
                $items[] = $this->formatData($categories, null, $locale);
            }
        }
        
        $this->categories = $this->mergeCategoriesLocales($items);
        $this->categoryCode = [];
        $this->firstRead = false;
    }
    /**
     * {@inheritdoc}
     */
    public function read()
    {
        if($this->itemIterator === null && $this->firstRead === false) {
            $this->itemIterator = new \ArrayIterator($this->categories);
            $this->firstRead = true;
        }
        
        $item = $this->itemIterator->current();
        if($item !== null && !empty($item['code'])) {
            if(!in_array($item['code'] , $this->categoryCode)) {
                $this->stepExecution->incrementSummaryInfo('read');
                $this->itemIterator->next();
                $this->categoryCode[] = $item['code'];
            } else {
                $this->stepExecution->incrementSummaryInfo('read_loacle');
                $this->itemIterator->next();
            }
        }
        
        return  $item;
    }


    protected function getCategories($store)
    {
        /* not store-view wise */
        
        $url = $this->oauthClient->getApiUrlByEndpoint('categories', $store);
        
        $method = 'GET';
        
        try {
            $this->oauthClient->fetch($url, null, $method, $this->jsonHeaders );
            $results = json_decode($this->oauthClient->getLastResponse(), true);
            
            return $results;
        } catch(\Exception $e) {
            $lastResponse = json_decode($this->oauthClient->getLastResponse(), true);
            $responseInfo = $this->oauthClient->getLastResponseInfo();
            foreach(array_keys($responseInfo) as $key ) {
                if(trim($key) == 'http_code') {
                    $lastResponse['http_code'] = $responseInfo[$key];
                    break;
                }
            }

            $error = ['error' => $lastResponse ];

            return $error;
        }
    }
    protected $parentCodes = []; 
    protected function formatData($category, $parentCode = null , $locale , $change = false)
    {
        $result = [];
        if(empty($category['id'])){ 
            return $result;
        }
        $tmpCode = $this->connectorService->findCodeByExternalId($category['id'], $this::AKENEO_ENTITY_NAME) ? : $category['name'];
        $code = $this->connectorService->matchCategoryCodeInDB($tmpCode) ? : $this->connectorService->convertToCode($tmpCode);
         
        if(empty($parentCode)) {
            if(!in_array($code, $this->parentCodes)) {
                $change = true;
            } 
            $check = $this->connectorService->findCodeByExternalId($category['id'], $this::AKENEO_ENTITY_NAME, $this->stepExecution->getJobExecution()->getId());
            if($check) {
              $this->parentCodes[] = $code; 
            }
        }
         
        if(!in_array($code, $this->categoryCode) ) {
            $this->categoryCode[] = $code; 
        } else {
            if($change) {
                $newCode = $code.rand();
                $this->stepExecution->addWarning("Catagory: already exist with this Code : $code. New Category $code has been created with Code: $newCode ",[], new DataInvalidItem(['code' => $code, 'newcode'=> $newCode]));
                $code = $newCode;
            }
        }
        
        if($parentCode) {
            $result[] = [
                'code'      => $code , //can fetch from db,
                'parent'    => $parentCode, //$this->connectorService->,
                'labels'    =>[
                    $locale => $category['name']
                ]
            ];            
        } else { 
            $result[] = [
                'code'      => $code, 
                'labels'    =>[
                    $locale => $category['name'],
                ]
            ];
        }

        // Add to Mapping in Database 
        $externalId = !empty($category['id']) ? $category['id'] : null;
        $relatedId = !empty($category['parent_id']) ? $category['parent_id'] : null;
        if($code && $externalId) {
            $mapping = $this->addMappingByCode($code, $externalId, $relatedId, $this::AKENEO_ENTITY_NAME);
        }

        if(!empty($category['children_data'])) {
            foreach($category['children_data'] as $subCategory) {
                $result = array_merge($result, $this->formatData($subCategory, $code, $locale, $change) );
            }
        }

        return $result;
    }

    protected function mergeCategoriesLocales($categoriesStoreWise) 
    {                 
        $categories = [];
        foreach($categoriesStoreWise as $categoryTree) {
            $categories = array_merge($categories, $categoryTree);
        }
        
         
        return $categories;
    }
}
