<?php

namespace Webkul\Magento2Bundle\Connector\Reader\Import;

use Akeneo\Component\Batch\Item\FileInvalidItem;
use Akeneo\Component\Batch\Item\InitializableInterface;
use Akeneo\Component\Batch\Item\FlushableInterface;
use Akeneo\Component\Batch\Item\InvalidItemException;
use Akeneo\Component\Batch\Item\ItemReaderInterface;
use Akeneo\Component\Batch\Model\StepExecution;
use Akeneo\Component\Batch\Step\StepExecutionAwareInterface;
use Webkul\Magento2Bundle\Component\OAuthClient;
use Webkul\Magento2Bundle\Services\Magento2Connector;
use Webkul\Magento2Bundle\Traits\DataMappingTrait;
use Webkul\Magento2Bundle\Connector\Reader\Import\BaseReader;

/**
 * import attributes reader from Magento 2 
 *
 * @author    webkul <support@webkul.com>
 * @copyright 2010-18 Webkul (http://store.webkul.com/license.html)
 */
class AttributeReader extends BaseReader implements ItemReaderInterface, StepExecutionAwareInterface, InitializableInterface
{
    use DataMappingTrait;

    protected $locale;

    protected $jsonHeaders = ['Content-Type' => 'application/json', 'Accept' => 'application/json'];

    protected $itemIterator;

    private $firstRead;

    private $items;

    protected $currentPage;

    protected $storeCode; 

    protected $attributeCode;

    const AKENEO_ENTITY_NAME = 'attribute';
    
    public function initialize()
    {
        $this->attributeCode = [];
        $this->attributeCount = 0;
        $credentials = $this->connectorService->getCredentials();
        if(!$this->oauthClient) {
            $this->oauthClient = new OAuthClient($credentials['authToken'], $credentials['hostName']);
        }
        $filters = $this->stepExecution->getJobParameters()->get('filters');
        $this->locale = !empty($filters['structure']['locale']) ? $filters['structure']['locale'] : (!empty($filters['structure']['locales'][0]) ? $filters['structure']['locales'][0]:'');
        $storeMapping = $this->connectorService->getStoreMapping();
        foreach($storeMapping as $storeCode => $storeData) {
            if($storeData['locale'] === $this->locale) {
                $this->storeCode = $storeCode;
                break; 
            }
        }

        $this->currentPage = 1;
        
        $attributes = $this->getAttributes($this->storeCode, $this->currentPage);
        $items = [];
        if(!empty($attributes['items'])) {
            $items = $this->formatData($attributes['items']);
        }
        
        $this->items = $items; 
        $this->firstRead = false;
    }

    /**
     * {@inheritdoc}
     */
    public function read()
    {
        
        if($this->itemIterator === null && $this->firstRead === false) {
            $this->itemIterator = new \ArrayIterator($this->items);
            $this->firstRead = true;
        }

        $item = $this->itemIterator->current();

        if($item !== null) {
            $this->stepExecution->incrementSummaryInfo('read');
            $this->itemIterator->next();
        } else {
            $this->currentPage++;
            $attributes = $this->getAttributes($this->storeCode, $this->currentPage);
            $items = [];
            if(!empty($attributes['items'])) {
                $items = $this->formatData($attributes['items']);
                $this->itemIterator = new \ArrayIterator($items);
                $item = $this->itemIterator->current();
                if($item !== null) {
                    $this->stepExecution->incrementSummaryInfo('read');
                    $this->itemIterator->next();
                }
            }
        }
        
        
        return  $item;
    }

    protected function getAttributes($storeCode, $currentPage , $pageSize = 50)
    {
        
        /* store-view wise and Page limit wise */
        $url = $this->oauthClient->getApiUrlByEndpoint('attributes', $storeCode);
        $url = strstr($url, '?', true) . '?searchCriteria[pageSize]='.$pageSize.'&searchCriteria[currentPage]=' . $currentPage;
        $method = 'GET';
        try {
            $this->oauthClient->fetch($url, null, $method, $this->jsonHeaders);
            $results = json_decode($this->oauthClient->getLastResponse(), true);
            if(!empty($results['total_count'])) {
                if($currentPage * $pageSize <= $results['total_count']) {
                    
                    return $results;
                } else {
                    $restPage = (($currentPage * $pageSize) - $results['total_count']);
                    if($restPage <  $pageSize) {
                        
                        return $results;
                    } else {
                        
                        return [];
                    }
                }    
            }
        } catch(\Exception $e) {
            $lastResponse = json_decode($this->oauthClient->getLastResponse(), true);
            throw new \Exception(
                !empty($lastResponse['message']) ? $lastResponse['message'] : "Error! can't get attributes"
            );
        }

        return [];
    }


    protected function formatData($attributes)
    {
        $results = [];
        // fetch attribute Mapping
        $attributeMappings = $this->connectorService->getAttributeMappings();        
        $attributeMappings = !empty($attributeMappings) ? $attributeMappings : [];
        //fetch other Mapping 
        $otherMapping = $this->connectorService->getOtherMappings();
        $finalOtherMapping = [];
        if(!empty($otherMapping['custom_fields'])) {
            foreach($otherMapping['custom_fields'] as $key => $value) {
                $finalOtherMapping[$value] = $value;
            }
        }
        
        foreach($attributes as $key => $attribute) {
            if(!$attribute['is_user_defined']) {
                if(!in_array($attribute['attribute_code'], $this->systemAttribute )) {
                    continue;
                }
            }

            $code = $this->connectorService->matchAttributeCodeInDb($attribute['attribute_code']) ? : $attribute['attribute_code'];
            
            $type = array_key_exists($attribute['frontend_input'], $this->attributeTypes) ? $this->attributeTypes[$attribute['frontend_input']] : null;
            
            if(!empty($type)) {    
                /* add attribute codes for attribute_option export */
                $this->addOptionAttributeCode($type, $attribute['attribute_code']);
                // if attribute present in mapping skipped
                if(array_key_exists(strtolower($code), array_change_key_case($attributeMappings)) ) {
                    $mapping = $this->connectorService->getAttributeByCode($attributeMappings[$code]);
                    if(!empty($mapping)){
                        $this->stepExecution->incrementSummaryInfo('read');
                        $this->stepExecution->incrementSummaryInfo('process');
                        continue;
                    }
                    $code = $attributeMappings[$code];
                    
                } else {
                    if(in_array($code , $this->attributeMapped) ) {
                        $attributeMappings[$code] = $code;
                        if(strcasecmp($code, 'qty') == 0 ){
                            $attributeMappings['quantity'] = $code;    
                        }
                        
                        //save attribute mapping in db
                        $this->connectorService->saveAttributeMappings($attributeMappings);    
                    } else {
                        if(in_array($code, array_keys($finalOtherMapping))) {
                            $mapping = $this->connectorService->getAttributeByCode($code);
                            if(!empty($mapping)){
                                $this->stepExecution->incrementSummaryInfo('read');
                                $this->stepExecution->incrementSummaryInfo('process');
                                continue;
                            }
                        } else {
                            $otherMapping['custom_fields'][] = $code;
                            $finalOtherMapping[$code] = $code;
                            
                            $this->connectorService->saveOtherMappings($otherMapping);
                        }       
                    }
                }

                if(in_array($code , $this->attributeCode)) {
                    continue;
                } else {
                    $this->attributeCode[] = $code;
                }
                
                $result = [
                    'code'                      => $code,
                    'localizable'               => $attribute['scope'] === 'store',
                    'scopable'                  => $attribute['scope'] !== 'global',
                    'sort_order'                => $attribute['position'],
                    'type'                      => $type,
                    'unique'                    => (boolean)$attribute['is_unique'],
                    'useable_as_grid_filter'    => $attribute['is_filterable_in_grid'],
                    'wysiwyg_enabled'           => $type === 'pim_catalog_textarea' ? (boolean)$attribute['is_wysiwyg_enabled'] : null,
                    'group'                     => 'other',  // change this
                ];
                
                if(!strcasecmp($result['code'] , 'sku')){
                    continue;
                }

                if($type === "pim_catalog_price_collection"){
                    $result['decimals_allowed'] =  true;
                }
                if($type === "pim_catalog_metric"){
                    $result["metric_family"] = "Weight";
                    $result["default_metric_unit"] = "POUND";
                    $result["decimals_allowed"] = true;
                    $result["negative_allowed"] = true;
                }
                
                $storeMapping = $this->connectorService->getStoreMapping();
                foreach($storeMapping as $storeCode => $storeData) {
                    if(!empty($storeData['locale'])) {
                        if($result['code'] ==='quantity_and_stock_status') {
                            $result['labels'][$storeData['locale']] = $result['code'];
                            continue;
                        }
                        $result['labels'][$storeData['locale']] = !empty($attribute['default_frontend_label']) ? $attribute['default_frontend_label'] : $result['code'];
                    }
                }
            
                // Add to Mapping in Database 
                $externalId = !empty($attribute['attribute_id']) ? $attribute['attribute_id'] : null;
                $relatedId = !empty($attribute['entity_type_id']) ? $attribute['entity_type_id'] : null;
                $code = !empty($result['code']) ? $result['code'] : null;
                if($code && $externalId && $relatedId){
                    $mapping = $this->addMappingByCode($code, $externalId, $relatedId, $this::AKENEO_ENTITY_NAME);
                }

                $results[] = $result;
            }
        }
        
        return $results;
    }

    protected function addOptionAttributeCode($type, $attributeCode )
    {
        /* add attribute codes for attribute_option export */
        if(in_array($type, ['pim_catalog_multiselect', 'pim_catalog_simpleselect'])) {
            $rawParams = $this->stepExecution->getJobExecution()->getJobInstance()->getRawParameters();
            if(empty($rawParams['selectTypeAttributes'])) {
                $rawParams['selectTypeAttributes'] = [];
            }
            $rawParams['selectTypeAttributes'][] = $attributeCode;
            $this->stepExecution->getJobExecution()->getJobInstance()->setRawParameters($rawParams);
            $rawParams = $this->stepExecution->getJobExecution()->getJobInstance()->getRawParameters();    
        }
    }

    protected $attributeTypes = [
        'text' => 'pim_catalog_text',
        'textarea' => 'pim_catalog_textarea',
        'date' => 'pim_catalog_date',
        'boolean' => 'pim_catalog_boolean',
        'multiselect' => 'pim_catalog_multiselect',
        'select' => 'pim_catalog_simpleselect',
        'price' => 'pim_catalog_price_collection',
        'weight' => 'pim_catalog_metric',
    ];  
    
    protected $attributeMapped = [
        'sku',
        'name',
        'weight',
        'price',
        'description',
        'short_description',
        'quantity',
        'meta_title',
        'meta_keyword',
        'meta_description',
        'url_key',
        'qty'
    ];

   
}
