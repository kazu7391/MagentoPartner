<?php

namespace Webkul\Magento2Bundle\Connector\Reader\Import;

use Akeneo\Component\Batch\Item\InitializableInterface;
use Akeneo\Component\Batch\Step\StepExecutionAwareInterface;
use Webkul\Magento2Bundle\Services\Magento2Connector;
use Akeneo\Component\Batch\Item\FileInvalidItem;
use Akeneo\Component\Batch\Item\FlushableInterface;
use Akeneo\Component\Batch\Item\InvalidItemException;
use Akeneo\Component\Batch\Item\ItemReaderInterface;
use Akeneo\Component\Batch\Model\StepExecution;
use Webkul\Magento2Bundle\Component\OAuthClient;
use Webkul\Magento2Bundle\Traits\DataMappingTrait;
use Webkul\Magento2Bundle\Connector\Reader\Import\BaseReader;
use Akeneo\Component\FileStorage\File\FileStorerInterface;
use Akeneo\Component\FileStorage\Repository\FileInfoRepositoryInterface;
use Pim\Component\Catalog\FileStorage;
use Symfony\Component\HttpFoundation\Request;
use Pim\Bundle\EnrichBundle\Controller\FileController;
use Pim\Bundle\EnrichBundle\Controller\Rest\FamilyVariantController;
use Akeneo\Component\Batch\Item\DataInvalidItem;

/**
 * import products_model from Magento 2
 *
 * @author    webkul <support@webkul.com>
 * @copyright 2010-18 Webkul (http://store.webkul.com/license.html)
 */
class ProductReader extends BaseReader implements ItemReaderInterface, StepExecutionAwareInterface, InitializableInterface
{
    use DataMappingTrait;
    
    protected $locale;

    protected $jsonHeaders = ['Content-Type' => 'application/json', 'Accept' => 'application/json'];

    protected $itemIterator;

    protected $storeMapping;

    protected $items;

    protected $firstRead;

    protected $family;

     /** @var FileStorerInterface */
     protected $storer;

     /** @var FileInfoRepositoryInterface */
    protected $fileInfoRepository;

    protected $uploadDir;

    protected $product_attributes;

    protected $parent;

    protected $familyVariantObject;

    protected $totalPages;

    protected $currentPage;
   
    public function __construct (
        Magento2Connector $connectorService,
        \Doctrine\ORM\EntityManager $em,
        FileStorerInterface $storer,
        FileInfoRepositoryInterface $fileInfoRepository,
        $uploadDir,
        FamilyVariantController $familyVariantObject
    ) { 
        parent::__construct($connectorService, $em);
        $this->storer = $storer;
        $this->fileInfoRepository = $fileInfoRepository;
        $this->uploadDir = $uploadDir;
        $this->familyVariantObject = $familyVariantObject;
    }


    public function initialize()
    {   
        $credentials = $this->connectorService->getCredentials();
        if(!$this->oauthClient) {
            $this->oauthClient = new OAuthClient($credentials['authToken'], $credentials['hostName']);
        }

        $filters = $this->stepExecution->getJobParameters()->get('filters');
        $this->locale = !empty($filters['structure']['locale']) ? $filters['structure']['locale'] : (!empty($filters['structure']['locales'][0]) ? $filters['structure']['locales'][0]:'');
        $this->scope = !empty($filters['structure']['scope']) ? $filters['structure']['scope'] : '';

        $storeMapping = $this->connectorService->getStoreMapping();    
        foreach($storeMapping as $storeCode => $storeData) {
            if($storeData['locale'] === $this->locale) {
                $this->storeCode = $storeCode;
                break; 
            }
        }
        
        $this->currentPage = 1; 
        $products = $this->getProducts($this->currentPage);
        $items = [];
        if(!empty($products['items'])) {
            $items = $this->formatData($products);
        }
        $this->items = $items; 
        $this->storeMapping = $this->connectorService->getStoreMapping();
        $this->firstRead = false;
    }
    
    public function read()
    {   
        if($this->itemIterator === null && $this->firstRead === false) {
            $this->itemIterator = new \ArrayIterator($this->items);
            $this->firstRead = true;
        }
        $item = $this->itemIterator->current();
        if($item !== null) {
            $this->stepExecution->incrementSummaryInfo('read');
            $this->itemIterator->next();
        } else {
            $this->currentPage++;
            $products = $this->getProducts($this->currentPage);
            if(!empty($products['items'])) {
                $this->items = $this->formatData($products);
                $this->itemIterator = new \ArrayIterator($this->items);
                $item = $this->itemIterator->current();
                if($item !== null) {
                    $this->stepExecution->incrementSummaryInfo('read');
                    $this->itemIterator->next();
                }
            }
        }
        
        return  $item;
    }

    protected function getProducts($currentPage , $pageSize = 50)
    {
        /* not store-view wise */
        $url = $this->oauthClient->getApiUrlByEndpoint('product', $this->storeCode);
        $url = str_replace('?searchCriteria=', '?searchCriteria[pageSize]='.$pageSize.'&searchCriteria[currentPage]=' . $currentPage , $url);
        $method = 'GET';
        
        try {
            $this->oauthClient->fetch($url, null, $method, $this->jsonHeaders );
            $results = json_decode($this->oauthClient->getLastResponse(), true);
            if(!empty($results['total_count'])) {
                if($currentPage * $pageSize <= $results['total_count']) {
                    
                    return $results;
                } else {
                    $restPage = (($currentPage * $pageSize) - $results['total_count']);
                    if($restPage <  $pageSize) {

                        return $results;
                    } else {
                        
                        return [];
                    }
                }    
            }
            
        } catch(\Exception $e) {
            $lastResponse = json_decode($this->oauthClient->getLastResponse(), true);
            $responseInfo = $this->oauthClient->getLastResponseInfo();
            foreach(array_keys($responseInfo) as $key ) {
                if(trim($key) == 'http_code') {
                    $lastResponse['http_code'] = $responseInfo[$key];
                    break;
                }
            }
            $error = ['error' => $lastResponse ];

            return $error;
        }
    }

    protected function formatData($products, $parentCode = null)
    {
        $results = [];
        foreach($products['items'] as $product){
            
            // if(strpos($product['sku'], ' ')) {
            //     $this->stepExecution->incrementSummaryInfo('read');
            //     $this->stepExecution->incrementSummaryInfo('skipped');
            //     $this->stepExecution->addWarning('SKU : property SKU contain spaces' , [], new DataInvalidItem(['sku' => $product['sku']]) );
            //     continue;
            // }
            if(empty($product['sku'])) {
                continue;
            }
            $productSKU = $product['sku'];
            $product = $this->getProductBySKU($product['sku'], $this->storeCode);

            if(isset($product['error'])) {
                $this->stepExecution->addWarning('Error: to fetch product from API ', [], new DataInvalidItem(["error" => $product, 'SKU' => $productSKU]));
                continue;
            }    
            
            if(!empty($product) && $product['type_id'] === 'simple') {
                $this->family  = !empty($product['attribute_set_id']) ? $this->connectorService->findCodeByExternalId($product['attribute_set_id'], 'family') : '';

                if(empty($this->family)) {
                    $this->stepExecution->incrementSummaryInfo('skipped');
                    $this->stepExecution->addWarning('Family is not present' , [], new DataInvalidItem(['family' => $this->family ]));
                    continue;
                }
                $result = [
                    'categories'     => !empty($product['custom_attributes']) ? $this->getCategories($product['custom_attributes']) : [],  
                    'enabled'        => !empty($product['status']) ? $this->getStatus($product['status']) : false ,
                    'family'         => $this->family,
                    'groups'         => [],
                    'identifier'     => !empty($product['sku']) ? $product['sku'] : null,
                ];
                
                // if sku not present 
                if(empty($result['values']['sku'])){
                    $result['values']['sku'] = [
                                array(
                                    'locale' => null,
                                    'scope' => null,
                                    'data' => $product['sku']
                                )
                            ];
                }


                $this->parent = $this->findParentCode($product['id']);
                if(!empty($this->parent)) {
                    $result['parent'] =  $this->parent;
                }

                $result['values'] = $this->getValues($product);
                $results[] = $result;
            }
        }

         
        return $results;
    }


    protected function getValues($product)
    {
        $result = parent::getValues($product);
        if(!empty($this->parent)) {
            $otherMappings = $this->connectorService->getOtherMappings();
            $credentials = $this->connectorService->getCredentials();
            $mapping = $this->getMappingByCode($this->parent, 'product');
            if($mapping){
                $familyCode = $mapping->getRelatedId();
                $familyVariant = $this->connectorService->getFamilyVariantByIdentifier($familyCode);
                if(!empty($familyVariant)) {     
                    $counter = 0;
                    foreach($familyVariant->getAttributes() as $attribute) {
                        if(in_array($attribute->getType() , ['pim_catalog_image']) ) {
                            $code = $attribute->getCode();
                            if(!empty($otherMappings) && !empty($otherMappings['images']) && !empty($otherMappings['images'][$counter]) ) {
                                $imageIndex =  $otherMappings['images'][$counter];
                                if(!empty($result[$imageIndex])) {
                                    $result[$code] = $result[$imageIndex];
                                    unset($result[$imageIndex]);
                                }
                                $counter++;
                            } else {
                                if(!empty($product['media_gallery_entries'][$counter])) {
                                    $imageArr = $product['media_gallery_entries'][$counter++];
                                    if($imageArr['media_type'] === 'image') {
                                        $imgUrl = $this->credentials['hostName'] . $this->media_dir . $imageArr['file'];
                                        $results = $this->connectorService->getAttributeTypeLocaleAndScope($image);
                                        $localizable = isset($results[0]['localizable']) ? $results[0]['localizable'] : null;
                                        $scopable = isset($results[0]['scopable']) ? $results[0]['scopable'] : null ;
                                        $result[$code] = [
                                            array(
                                                'locale' => $localizable ? $this->locale : null,
                                                'scope' => $scopable ? $this->scope : null,
                                                'data' => $this->imageStorer($imgUrl), //image
                                            )
                                        ];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        return $result;
    }
       
    protected function getStatus($status)
    {
        if($status == 1){
            return true;
        }else{
            return false;
        }
    }


    protected function findParentCode($productId)
    {

        $mappingResults = $this->connectorService->getMappingByEntity('product_links', $this->stepExecution->getJobExecution()->getId());
        
        if($mappingResults){
            foreach($mappingResults as $mappingResult){
                if(!empty($mappingResult['relatedId'] )) {
                    $relatedIds = json_decode($mappingResult['relatedId']);
                    $product_links = !empty($relatedIds->configurable_product_links) ? $relatedIds ->configurable_product_links : [] ;
                    $this->product_attributes = !empty($relatedIds->configurable_product_options) ? $relatedIds->configurable_product_options : [] ;
                    
                    if(in_array($productId, $product_links)){
                        
                        return $mappingResult['code'];
                    }
                }
            }
        }
        
        return null;
    }
}
