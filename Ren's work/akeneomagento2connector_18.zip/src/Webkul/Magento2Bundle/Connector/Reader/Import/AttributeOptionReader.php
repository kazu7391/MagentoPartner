<?php

namespace Webkul\Magento2Bundle\Connector\Reader\Import;

use Akeneo\Component\Batch\Item\InitializableInterface;
use Akeneo\Component\Batch\Step\StepExecutionAwareInterface;
use Akeneo\Component\Batch\Item\FileInvalidItem;
use Akeneo\Component\Batch\Item\FlushableInterface;
use Akeneo\Component\Batch\Item\InvalidItemException;
use Akeneo\Component\Batch\Item\ItemReaderInterface;
use Akeneo\Component\Batch\Model\StepExecution;
use Webkul\Magento2Bundle\Component\OAuthClient;
use Webkul\Magento2Bundle\Services\Magento2Connector;
use Akeneo\Component\Batch\Item\DataInvalidItem;
use Webkul\Magento2Bundle\Traits\DataMappingTrait;
use Webkul\Magento2Bundle\Connector\Reader\Import\BaseReader;

/**
 * import attributes' option from Magento 2 
 *
 * @author    webkul <support@webkul.com>
 * @copyright 2010-18 Webkul (http://store.webkul.com/license.html)
 */
class AttributeOptionReader extends BaseReader implements ItemReaderInterface, StepExecutionAwareInterface , InitializableInterface
{
    use DataMappingTrait;    

    protected $locale;

    protected $jsonHeaders = ['Content-Type' => 'application/json', 'Accept' => 'application/json'];

    protected $itemIterator;

    protected $storeMapping;
    
    protected $firstRead;

    protected $items;

    const AKENEO_ENTITY_NAME = 'option';

    protected $optionCodes;

    protected $counter;
    protected $locales;
    
    public function initialize()
    {
        $repo2 = $this->em->getRepository('PimCatalogBundle:Locale');
        $activeLocales = $repo2->getActivatedLocales();
                
        foreach($activeLocales as $activeLocale){
            $locale = $activeLocale->getCode();
            $this->locales[$locale] = $locale ;
        }

        $credentials = $this->connectorService->getCredentials();
        if(!$this->oauthClient) {
            $this->oauthClient = new OAuthClient($credentials['authToken'], $credentials['hostName']);
        }
        $filters = $this->stepExecution->getJobParameters()->get('filters');
        $this->locale = !empty($filters['structure']['locale']) ? $filters['structure']['locale'] : (!empty($filters['structure']['locales'][0]) ? $filters['structure']['locales'][0]:'');

        $this->optionCodes = [];
        $rawParams = $this->stepExecution->getJobExecution()->getJobInstance()->getRawParameters();
        $this->storeMapping = $this->connectorService->getStoreMapping();
        $this->attributes = !empty($rawParams['selectTypeAttributes']) ? array_values(array_unique($rawParams['selectTypeAttributes'])) : [];
        $this->totalAttribute = count($this->attributes);
        
        $items = [];
        $this->counter = 0;
        if(!empty($this->totalAttribute)) {
            $items = $this->getPageWiseAttributeOptions($this->counter);
        }
        
        $this->items = $items;
        $this->firstRead = false;
    }

    /**
     * {@inheritdoc}
     */
    public function read()
    {
        if($this->itemIterator === null && $this->firstRead === false) {
            $this->itemIterator = new \ArrayIterator($this->items);
            $this->firstRead = true;
        }
        
        $item = $this->itemIterator->current();

        if($item !== null) {
            $this->stepExecution->incrementSummaryInfo('read');
            $this->itemIterator->next();
        } else {
            $this->counter++;
            while($this->counter < $this->totalAttribute) {
                $items = $this->getPageWiseAttributeOptions($this->counter);
                $this->itemIterator = new \ArrayIterator($items);
                $item = $this->itemIterator->current();        
                if($item !== null) {
                    $this->stepExecution->incrementSummaryInfo('read');
                    $this->itemIterator->next();
                    break; 
                } else {
                    $this->counter++;
                }
            }
        } 
        
        return $item;
    }

    protected function getAttributeOptions($attributeCode , $store)
    {
        $url = $this->oauthClient->getApiUrlByEndpoint('attributeOption', $store);
        $url = str_replace('{attributeCode}', $attributeCode, $url);
        $method = 'GET';        
        try {
            $this->oauthClient->fetch($url, null, $method, $this->jsonHeaders );
            $results = json_decode($this->oauthClient->getLastResponse(), true);
            
            return $results;
        } catch(\Exception $e) {
            $lastResponse = json_decode($this->oauthClient->getLastResponse(), true);
            throw new \Exception(
                !empty($lastResponse['message']) ? $lastResponse['message'] : "Error! can't get attribute options"
            );
        }
    }

    protected function formatOptionsData($optionsStoreWise, $attributeCode)
    {       
        $results = [];
        
        foreach($optionsStoreWise as $storeLocale => $options) {
            foreach($options as $option){
                if(isset($option['value']) && !empty($option['label']) ) {
                    $localWiseOptions[$option['value']][$storeLocale] = $option['label'];
                }
            }
        }    
        $sort_order = 0; 
        
        foreach($localWiseOptions as $optionCode => $option) {
            $code = $this->connectorService->convertToCode($option['code']) ;

            $mappingCode = !empty($code) ? $code . '('. $attributeCode .')' : null;                      

            if(in_array($mappingCode , $this->optionCodes)) {
                // Duplicate Optioncode mapping in db 
                $externalId = $optionCode;
                $relatedId = $attributeCode;
                if($code && $externalId !== null){
                    $mapping = $this->addMappingByExternalId($mappingCode, $externalId, $relatedId, $this::AKENEO_ENTITY_NAME);
                   
                }
                $this->stepExecution->incrementSummaryInfo('read');
                $this->stepExecution->incrementSummaryInfo('skip');
                $this->stepExecution->addWarning("Duplicate Option Found: Duplicate Option $code in Attribute $attributeCode", [], new DataInvalidItem(['option code' => $code , 'attribute Code' => $attributeCode]) );

                continue;
            } else {
                $this->optionCodes[] = $mappingCode;
            }

            $mapping = $this->connectorService->attributeOptionCheckInDB($code , $attributeCode);          
            
            if(!empty($mapping)) {
                 // Already exist mapping in db 
                 $externalId = $optionCode;
                 $relatedId = $mapping['attributeId'];
                 $code = $this->connectorService->convertToCode($mapping['code']);
                 $mappingCode = !empty($code) ? $code . '('. $attributeCode .')' : null;
                 if($mappingCode && $externalId !== null){
                    $mapping = $this->addMappingByExternalId($mappingCode, $externalId, $relatedId, $this::AKENEO_ENTITY_NAME);
                 }
                 $this->stepExecution->incrementSummaryInfo('read');
                 $this->stepExecution->incrementSummaryInfo('process');
                continue;
                // $result['id'] = $mapping['id'];
            }

            $result = [
                'code'          => $code,
                'attribute'     => $attributeCode,
                'sort_order'    => ++$sort_order,
            ];
            
            foreach($option as $optionLocale => $optionLabel) {
                if(in_array($optionLocale , $this->locales)) {
                    $result['labels'][$optionLocale] = $optionLabel;
                }
            }
            
            // Add to Mapping in Database 
            $externalId = $optionCode;
            $relatedId = $attributeCode;
            $code = $mappingCode;
            if($code && $externalId !== null){
                $mapping = $this->addMappingByExternalId($code, $externalId, $relatedId, $this::AKENEO_ENTITY_NAME);
            }
                        
            $results[] = $result;
        }
        
        return $results;
    }



    protected $attributeTypes = [
        'text'          => 'pim_catalog_text',
        'textarea'      => 'pim_catalog_textarea',
        'date'          => 'pim_catalog_date',
        'boolean'       => 'pim_catalog_boolean',
        'multiselect'   => 'pim_catalog_multiselect',
        'select'        => 'pim_catalog_simpleselect',
        'price'         => 'pim_catalog_price_collection',
    ];    

    protected function getPageWiseAttributeOptions($counter) 
    {
        $items = [];
        $options = [];
        $attributeCode = !empty($this->attributes[$counter]) ? $this->attributes[$counter] : '';
        
        if(!empty($attributeCode)) {
            // store wise options
            foreach ($this->storeMapping as $storeCode => $storeMappedData) {
                if(!empty($storeMappedData['locale'])) {
                    $attributeOptions = $this->getAttributeOptions($attributeCode, $storeCode);    
                    foreach($attributeOptions as $index => $attributeOptionValue) {
                        if(empty($attributeOptionValue['label']))  {
                            unset($attributeOptions[$index]);
                        }
                    }
                    if(!empty($attributeOptions)) {   
                        $options[$storeMappedData['locale']] = $attributeOptions;
                    }
                }
            }
            
            if(!empty($options)) {
                //for option code
                $options['code'] = $this->getAttributeOptions($attributeCode, 'all');

                // Add option in according to attribute mapping akeneo attributes
                $attributeMappings = $this->connectorService->getMergeMappings();
                if(in_array($attributeCode , array_keys($attributeMappings))){
                    $attributeCode = $attributeMappings[$attributeCode];
                }
                $formattedItems = $this->formatOptionsData($options, $attributeCode);  
                
                foreach($formattedItems as $formattedItem){
                    if(!empty($formattedItem['code'])  ){
                        $items[] = $formattedItem;
                    }
                }
            }            
        }
        
        return $items;
    }
}
