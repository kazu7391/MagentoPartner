<?php

namespace Webkul\Magento2Bundle\Connector\Reader\Import;

use Akeneo\Component\Batch\Item\InitializableInterface;
use Akeneo\Component\Batch\Step\StepExecutionAwareInterface;
use Akeneo\Component\Batch\Item\FileInvalidItem;
use Akeneo\Component\Batch\Item\FlushableInterface;
use Akeneo\Component\Batch\Item\InvalidItemException;
use Akeneo\Component\Batch\Item\ItemReaderInterface;
use Akeneo\Component\Batch\Model\StepExecution;
use Webkul\Magento2Bundle\Component\OAuthClient;
use Webkul\Magento2Bundle\Services\Magento2Connector;
use Webkul\Magento2Bundle\Traits\DataMappingTrait;
use Webkul\Magento2Bundle\Connector\Reader\Import\BaseReader;
/**
 * import attribute groups from Magento 2 
 *
 * @author    webkul <support@webkul.com>
 * @copyright 2010-18 Webkul (http://store.webkul.com/license.html)
 */
class AttributeGroupReader extends BaseReader implements ItemReaderInterface, StepExecutionAwareInterface, InitializableInterface
{
    use DataMappingTrait;

    // protected $rootCategoryCode;

    protected $locale;

    protected $oauthClient;

    protected $jsonHeaders = ['Content-Type' => 'application/json', 'Accept' => 'application/json'];

    protected $itemIterator;

    protected $mappedFields;

    protected $storeMapping;

    protected $attributeSetIds;

    protected $currentPage;

    protected $attributesCode;

    protected $items;

    protected $firstRead;

    const ENTITY_OTHER_MAPPING = 'magento2_other_mapping';

    const ENTITY_ATTRIBUTE_MAPPING = 'magento2_attribute_mapping';

    const ENTITY_STORE_MAPPING = 'magento2_store_mapping';

    const AKENEO_ENTITY_NAME = 'group';

    /**
     * {@inheritdoc}
     */
    public function initialize()
    {
        $this->attributesCode = []; // for unique attributeCode
        $credentials = $this->connectorService->getCredentials();
        if(!$this->oauthClient) {
            $this->oauthClient = new OAuthClient($credentials['authToken'], $credentials['hostName']);
        }

        $filters = $this->stepExecution->getJobParameters()->get('filters');
        $channelCode = !empty($filters['structure']['scope']) ? $filters['structure']['scope'] : '';
        $channel = $channelCode ? $this->connectorService->findChannelByIdentifier($channelCode) : null;
        $this->locale = !empty($filters['structure']['locale']) ? $filters['structure']['locale'] : (!empty($filters['structure']['locales'][0]) ? $filters['structure']['locales'][0]:'');
        $this->currentPage = 1;
        $this->items = $this->getAttributeGroupsByPageSize($this->currentPage);
       ;
        $this->firstRead = false;
    }

    /**
     * {@inheritdoc}
     */
    public function read()
    {
        if($this->itemIterator === null && $this->firstRead === false) {            
            $this->itemIterator = new \ArrayIterator($this->items);
            $this->firstRead = true;
        }

        $item = $this->itemIterator->current();

        if($item !== null) {
            $this->stepExecution->incrementSummaryInfo('read');
            $this->itemIterator->next();
        } else {
            $this->currentPage++;
            $items = $this->getAttributeGroupsByPageSize($this->currentPage);
            if(!empty($items)) {
                $this->itemIterator = new \ArrayIterator($items);
                $item = $this->itemIterator->current();
                if($item !== null) {
                    $this->stepExecution->incrementSummaryInfo('read');
                    $this->itemIterator->next();
                }
            }
        }
        
        return $item;
    }

    // Formate data according to akeneo processor
    protected function formateData($attributeGroups){
        $items = [];
        foreach($attributeGroups as $attributeGroupId => $attributeGroup){
            $attributeGroupName = $attributeGroup['attribute_group_name'] ? $attributeGroup['attribute_group_name'] : '';
            $code = $this->connectorService->convertToCode($attributeGroupName);
            if(in_array($code , $this->attributesCode) ) {
                continue;
            } else {
                $this->attributesCode[] = $code;
            }

            $formatted = [
                "code" => $code,
                "attributes" => [],
                "sort_order" => "0",
            ];

            $storeMapping = $this->connectorService->getStoreMapping();
            foreach($storeMapping as $storeCode => $storeData) {
                if(!empty($storeData['locale'])) {
                    $formatted['labels'][$storeData['locale']] = !empty($attributeGroup['attribute_group_name']) ? $attributeGroup['attribute_group_name'] : '' ;
                }
            }
            
            // Add to Mapping in Database 
            $externalId = !empty($attributeGroup['attribute_group_id']) ? $attributeGroup['attribute_group_id'] : null;
            $relatedId = !empty($attributeGroup['attribute_set_id']) ? $attributeGroup['attribute_set_id'] : null;
            if($code && $externalId && $relatedId){
                $mapping = $this->addMappingByCode($code, $externalId, $relatedId, $this::AKENEO_ENTITY_NAME);
            }

            $items[] = $formatted;
        }
        
        return $items;
    }

    protected function getAttributeGroups($attributeSetId)
    {
        $url = $this->oauthClient->getApiUrlByEndpoint('getAttributeGroup');
        $url = str_replace('?searchCriteria=','?searchCriteria[filterGroups][0][filters][0][field]=attribute_set_id&searchCriteria[filterGroups][0][filters][0][value]='.$attributeSetId, $url);  
        $method = 'GET';
        
        try {
            $this->oauthClient->fetch($url, null, $method, $this->jsonHeaders );
            $results = json_decode($this->oauthClient->getLastResponse(), true);
            
            return $results;
        } catch(\Exception $e) {
            $lastResponse = json_decode($this->oauthClient->getLastResponse(), true);
            throw new \Exception(
                !empty($lastResponse['message']) ? $lastResponse['message'] : "Error! can't get Attribute Group"
            );
        }
    }

    protected function normalizeAttributeGroupsByName($attributeGroupSet)
    {
        foreach($attributeGroupSet["items"] as $attributeGroup){
            $attributeGroupName[] = $attributeGroup;
        }

        return $attributeGroupName;
    }

    protected function getAttributeSetIds($currentPage , $pageSize = 1)
    {
        $url = $this->oauthClient->getApiUrlByEndpoint('getAttributeSets');
        $url = strstr($url, "[pageSize]" , true) . '[pageSize]='.$pageSize.'&searchCriteria[currentPage]='.$currentPage;
        $method = 'GET';

        try{
            $this->oauthClient->fetch($url, null, $method, $this->jsonHeaders );
            $results = json_decode($this->oauthClient->getLastResponse(), true);
            $attributeSetIds = [];

            if($currentPage * $pageSize <= $results['total_count']) {
                if(!empty($results['items'])) {
                    foreach( $results['items'] as $attributeSet) {
                        $attributeSetIds[] = $attributeSet['attribute_set_id'] ? $attributeSet['attribute_set_id'] : '';
                    }
                }
                
                return $attributeSetIds;
            } else {
                $restPage = (($currentPage * $pageSize) - $results['total_count']);
                if($restPage <  $pageSize) {
                    
                    return $results;
                } else {
                    
                    return [];
                }
            }   

        }catch(\Exception $e) {    

        }
    }

    private function getAttributeGroupsByPageSize($currentPage) 
    {
        $items = [];

        $attributeSetIds =  $this->getAttributeSetIds($currentPage);
        if(is_array($attributeSetIds)) {
            foreach($attributeSetIds as $attributeSetId) {
                if(!empty($attributeSetId)) {
                    $attributeGroups = $this->normalizeAttributeGroupsByName($this->getAttributeGroups($attributeSetId));
                    $attributeGroups = $this->formateData($attributeGroups);
                    if(!empty($attributeGroups) && is_array($attributeGroups)) {
                        $items = array_merge($attributeGroups, $items);
                    }
                }
            }
        }

        return $items;
    }

}
