<?php

namespace Webkul\Magento2Bundle\Connector\Processor;

use Pim\Component\Connector\Processor\Normalization\ProductProcessor as PimProductProcessor;
use Webkul\Magento2Bundle\Traits\FileInfoTrait;
use Webkul\Magento2Bundle\Traits\StepExecutionTrait;
use Symfony\Component\Serializer\Normalizer\NormalizerInterface;
use Pim\Component\Catalog\Repository\ChannelRepositoryInterface;
use Akeneo\Component\StorageUtils\Detacher\ObjectDetacherInterface;
use Akeneo\Component\Batch\Model\StepExecution;
use Pim\Component\Catalog\ValuesFiller\EntityWithFamilyValuesFillerInterface;
use Pim\Component\Catalog\Model\ProductModel;
use Akeneo\Component\Batch\Item\DataInvalidItem;
use Akeneo\Component\Batch\Job\JobParameters;
 
/**
 * Product processor to process and normalize entities to the standard format
 *
 */
class ProductAssociationProcessor extends PimProductProcessor
{
    use FileInfoTrait;
    use StepExecutionTrait;
    
    /** @var NormalizerInterface */
    protected $normalizer;

    /** @var ChannelRepositoryInterface */
    protected $channelRepository;

    /** @var ObjectDetacherInterface */
    protected $detacher;

    /** @var StepExecution */
    protected $stepExecution;

    /** @var EntityWithFamilyValuesFillerInterface */
    protected $productValuesFiller;

    protected $channel;

    protected $connectorService;

    /**
     * @param NormalizerInterface                   $normalizer
     * @param ObjectDetacherInterface               $detacher
     * @param ChannelRepositoryInterface            $channelRepository
     * @param EntityWithFamilyValuesFillerInterface $productValuesFiller
     */
    public function __construct(
        NormalizerInterface $normalizer,
        ObjectDetacherInterface $detacher,
        ChannelRepositoryInterface $channelRepository,
        EntityWithFamilyValuesFillerInterface $productValuesFiller
        
    ) {
        $this->normalizer = $normalizer;
        $this->detacher = $detacher;
        $this->channelRepository = $channelRepository;
        $this->productValuesFiller = $productValuesFiller;
    }

    /**
     * {@inheritdoc}
     */
    public function process($product, $recursiveCall = false)
    {
        $productAssociations = array();
        
        if(!$recursiveCall && $product instanceof ProductModel) {
            /* skip excess ProductModel */
            return;
        }

        $parameters = $this->stepExecution->getJobParameters();

        if($scope = $this->getChannelScope($this->stepExecution)) {
            $channel = $this->channelRepository->findOneByIdentifier($scope);
            $this->channel = $scope;;
        }

        if(!$recursiveCall) {
            $this->productValuesFiller->fillMissingValues($product);

            $productStandard = $this->normalizer->normalize($product, 'standard', [
                'channels' => !empty($channel) ? [$channel->getCode()] : [],
                'locales'  => array_intersect(
                    !empty($channel) ? $channel->getLocaleCodes() : [],
                    $this->getFilterLocales($this->stepExecution)
                ),
            ]);
        } else {
            $productStandard = $product;            
        }
        
        if(isset($productStandard['associations']) && isset($productStandard['metadata']['identifier'])) {
            $productAssociations = array(
                                                'sku' => $productStandard['metadata']['identifier'], 
                                                'associations' =>$productStandard['associations'] 
                                            );
        }

        return $productAssociations;
    }
}   