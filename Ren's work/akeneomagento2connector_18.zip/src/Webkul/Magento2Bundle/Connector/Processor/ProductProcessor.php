<?php

namespace Webkul\Magento2Bundle\Connector\Processor;

use Akeneo\Component\Batch\Item\DataInvalidItem;
use Akeneo\Component\Batch\Job\JobParameters;
use Akeneo\Component\Batch\Model\StepExecution;
use Akeneo\Component\StorageUtils\Detacher\ObjectDetacherInterface;
use Pim\Component\Catalog\Repository\AttributeRepositoryInterface;
use Pim\Component\Catalog\Repository\ChannelRepositoryInterface;
use Pim\Component\Catalog\ValuesFiller\EntityWithFamilyValuesFillerInterface;
use Pim\Component\Connector\Processor\BulkMediaFetcher;
use Symfony\Component\Serializer\Normalizer\NormalizerInterface;
use Pim\Component\Connector\Processor\Normalization\ProductProcessor as PimProductProcessor;
use Symfony\Bundle\FrameworkBundle\Routing\Router;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Webkul\Magento2Bundle\Traits\FileInfoTrait;
use Webkul\Magento2Bundle\Traits\StepExecutionTrait;
use Webkul\Magento2Bundle\Component\Normalizer\PropertiesNormalizer as Prop;
use Pim\Component\Catalog\Model\ProductModel;

/**
 * Product processor to process and normalize entities to the standard format
 *
 */
class ProductProcessor extends PimProductProcessor
{
    use FileInfoTrait;
    use StepExecutionTrait;
    
    /** @var NormalizerInterface */
    protected $normalizer;

    /** @var ChannelRepositoryInterface */
    protected $channelRepository;

    /** @var AttributeRepositoryInterface */
    protected $attributeRepository;

    /** @var ObjectDetacherInterface */
    protected $detacher;

    /** @var StepExecution */
    protected $stepExecution;

    /** @var BulkMediaFetcher */
    protected $mediaFetcher;

    /** @var EntityWithFamilyValuesFillerInterface */
    protected $productValuesFiller;

    protected $magentoInternalFields = ['id', 'created_at', 'updated_at', 'type_id'];
    protected $magentoBaseFields = ['sku', 'name', 'price', 'status', 'visibility', 'weight'];
    
    protected $magentoNoncustomValuesArray = [
        'categories', 'axes', 'variants', 'allVariantAttributes'
    ];

    protected $channel;

    protected $router;

    protected $connectorService;

    /**
     * @param NormalizerInterface                   $normalizer
     * @param ChannelRepositoryInterface            $channelRepository
     * @param AttributeRepositoryInterface          $attributeRepository
     * @param ObjectDetacherInterface               $detacher
     * @param BulkMediaFetcher                      $mediaFetcher
     * @param EntityWithFamilyValuesFillerInterface $productValuesFiller
     */
    public function __construct(
        NormalizerInterface $normalizer,
        ChannelRepositoryInterface $channelRepository,
        AttributeRepositoryInterface $attributeRepository,
        ObjectDetacherInterface $detacher,
        BulkMediaFetcher $mediaFetcher,
        EntityWithFamilyValuesFillerInterface $productValuesFiller,
        Router $router,
        $connectorService
    ) {
        $this->normalizer = $normalizer;
        $this->detacher = $detacher;
        $this->channelRepository = $channelRepository;
        $this->attributeRepository = $attributeRepository;
        $this->mediaFetcher = $mediaFetcher;
        $this->productValuesFiller = $productValuesFiller;
        $this->router = $router;
        $this->connectorService = $connectorService;
    }

    /**
     * {@inheritdoc}
     */
    public function process($product, $recursiveCall = false)
    {
        if(!$recursiveCall && $product instanceof ProductModel) {
            /* skip excess ProductModel */
            return;
        }

        $parameters = $this->stepExecution->getJobParameters();

        if($scope = $this->getChannelScope($this->stepExecution)) {
            $channel = $this->channelRepository->findOneByIdentifier($scope);
            $this->channel = $scope;;
        }

        if(!$recursiveCall) {
            $this->productValuesFiller->fillMissingValues($product);

            $productStandard = $this->normalizer->normalize($product, 'standard', [
                'channels' => !empty($channel) ? [$channel->getCode()] : [],
                'locales'  => array_intersect(
                    !empty($channel) ? $channel->getLocaleCodes() : [],
                    $this->getFilterLocales($this->stepExecution)
                ),
            ]);
        } else {
            $productStandard = $product;            
        }

        if(!$recursiveCall && !empty($productStandard['parent'])) {
            $parentProductStandard = $productStandard['parent'];
            if(isset($productStandard[Prop::FIELD_ENABLED])) {
                $parentProductStandard['status'] = $productStandard[Prop::FIELD_ENABLED];
            }            
            $productStandard['parent'] = $this->process($parentProductStandard, true);
        } 

        $this->fillProductValues($productStandard);
        if ($this->areAttributesToFilter($parameters)) {
            $attributesToFilter = $this->getAttributesToFilter($parameters);
            $productStandard['values'] = $this->filterValues($productStandard['values'], $attributesToFilter);
        }
        if(isset($productStandard['associations'])) {
            unset($productStandard['associations']);
        }
        ///////////// custom code start ////////////// 
        $otherMappings = $this->connectorService->getOtherMappings();
        $otherSettings = $this->connectorService->getSettings();

        /* images */
        if ($parameters->has('with_media') && $parameters->get('with_media')) {
            // $mediaAttributes = $this->attributeRepository->findMediaAttributeCodes();
            $mediaAttributes = !empty($otherMappings['images']) ? $otherMappings['images'] : [];

            $productStandard['media_gallery_entries'] = [];
             
            foreach($mediaAttributes as $mediaAttribute) {
                if($this->isSameLevelImage($mediaAttribute, $productStandard)) {
                    if(!empty($productStandard['values'][$mediaAttribute])) {
                        $convertedImage = $this->convertRelativeUrlToBase64(
                            $productStandard['values'][$mediaAttribute], 
                            (!empty($productStandard['name']) ? $productStandard['name'] : ''),
                            $mediaAttribute == $productStandard[Prop::FIELD_META_DATA][Prop::ATTRIBUTE_AS_IMAGE] ? 0 : count($productStandard['media_gallery_entries'])
                            );
                             
                        if($convertedImage) {
                            $productStandard['media_gallery_entries'][] = $convertedImage;                            
                        }
                    }
                }
                unset($productStandard['values'][$mediaAttribute]);
            }
        }

        /* add attribute to process */ 
        $attributeMappings = $this->connectorService->getAttributeMappings();
        $flippedMappings = array_flip($attributeMappings);
        $productStandard[Prop::FIELD_META_DATA]['unprocessed'] = [];
        $productStandard['custom_attributes'] = [];

        if(!empty($productStandard[Prop::FIELD_META_DATA][Prop::FIELD_IDENTIFIER])) {
            if(isset($productStandard[Prop::FIELD_ENABLED])) {
                $productStandard['status'] = $productStandard[Prop::FIELD_ENABLED];
            }
        }
        
        /* custom attributes indexing */
        foreach($productStandard['values'] as $field => $value) {

            if(!$recursiveCall || $this->isSameLevelAttribute($field, $productStandard) || in_array($field, ['categories'])) {
                
                /* sku */ 
                if($field == 'sku' || $field == 'SKU') {
                    $productStandard['sku'] = $this->formatValueForMagento($value);
                /* mapped attributes (standard) */
                } else if(in_array($field, array_values($attributeMappings))) {
                    
                    if(isset($flippedMappings[$field])) {
                        switch($flippedMappings[$field]) {
                            case 'quantity':
                                $productStandard[$flippedMappings[$field]] = $value;
                                $productStandard[Prop::FIELD_META_DATA]['unprocessed'][] = $flippedMappings[$field];
                                break;
                            case 'visibility':                            
                            case 'status':
                                $value = intval($this->formatValueForMagento($value));
                                if($field == 'visibility' && !$value) {
                                    break;
                                }
                            /* base attributes */ 
                            case in_array($flippedMappings[$field], $this->magentoBaseFields) ? true :false:
                                $productStandard[$flippedMappings[$field]] = $value;
                                $productStandard[Prop::FIELD_META_DATA]['unprocessed'][] = $flippedMappings[$field];                            
                                break;
                                
                            case in_array($flippedMappings[$field], $this->stockItemFields) ? true : false:
                                $productStandard[$flippedMappings[$field]] = $value;
                                $productStandard[Prop::FIELD_META_DATA]['unprocessed'][] = $flippedMappings[$field];                            
                                break;
                            /* standard/custom attributes */
                            default:
                                $productStandard['custom_attributes'][] = [
                                    'attribute_code' => $flippedMappings[$field],
                                    'value'          => $value,
                                ];
                        }
                    }

                /* custom mapped attributes */
                } else if(!empty($otherMappings['custom_fields']) && in_array($field, $otherMappings['custom_fields'])) {
                    $customValue = [
                        'attribute_code' => $field,
                        'value'          => $value,
                    ];
                    $productStandard['custom_attributes'][] = $customValue;

                    if(in_array($field, $this->stockItemFields) ){
                        
                        $productStandard[$field] = $value;
                        $productStandard[Prop::FIELD_META_DATA]['unprocessed'][] = $field;   
                    }

                /* meta data fields */                    
                } else if(in_array($field, $this->magentoNoncustomValuesArray)) {
                    $productStandard[Prop::FIELD_META_DATA][$field] =  $value;
                    unset($productStandard[$field]);
                }

                if(!empty($otherSettings['fallbackName']) && $field == $otherSettings['fallbackName']) {
                    $productStandard[Prop::FIELD_META_DATA]['fallbackName'] = $value;                
                }
                
            }
        }

        if(empty($productStandard['sku']) && !empty($productStandard[Prop::FIELD_META_DATA][Prop::FIELD_IDENTIFIER])) {
            $productStandard['sku'] = $productStandard[Prop::FIELD_META_DATA][Prop::FIELD_IDENTIFIER];
        }

        unset($productStandard['values']);

        if(!$recursiveCall) {            
            $this->detacher->detach($product);
        }
        
        return $productStandard;
    }

    /**
     * {@inheritdoc}
     */
    public function setStepExecution(StepExecution $stepExecution)
    {
        $this->stepExecution = $stepExecution;
    }

    protected function isSameLevelImage($attrCode, $productStandard)
    {
        if(!empty($productStandard[Prop::FIELD_PARENT]) ) {
            $childLevelAttribute = $productStandard[Prop::VARIANT_ATTRIBUTES];
            $flag = in_array($attrCode, $childLevelAttribute);
        } else {
            $flag = $this->isSameLevelAttribute($attrCode, $productStandard);
        }

        return $flag;
    }

    protected function isSameLevelAttribute($attrCode, $productStandard)
    {
        $flag = isset($productStandard[Prop::VARIANT_ATTRIBUTES]) && !in_array($attrCode, $productStandard[Prop::VARIANT_ATTRIBUTES]);

        return !$flag;
    }


    /**
     * Filters the attributes that have to be exported based on a product and a list of attributes
     *
     * @param array $values
     * @param array $attributesToFilter
     *
     * @return array
     */
    protected function filterValues(array $values, array $attributesToFilter)
    {
        $valuesToExport = [];
        $attributesToFilter = array_flip($attributesToFilter);
        foreach ($values as $code => $value) {
            if (isset($attributesToFilter[$code])) {
                $valuesToExport[$code] = $value;
            }
        }

        return $valuesToExport;
    }

    private function formatValueForMagento($value)
    {
        if(is_array($value)) {
            foreach($value as $key => $data) {
                if($this->channel && isset($data['scope']) &&  $data['scope'] !== $this->channel) {
                    continue;
                }
                if($this->channel && isset($data['locale']) &&  $data['locale'] !== $this->locale) {
                    continue;
                }
                $value = !empty($data['data']) ? $data['data'] : null;
            }
        }

        return $value;
    }

    protected function convertRelativeUrlToBase64($entry, $productName = '', $position = 0)
    {
        if(is_array($entry)) {
            if(!empty($entry[0]['data']) ) {
                $entry = $entry[0]['data'];
            } else {
                return;
            }
        }

        $filename = explode('/', $entry);
        $filename = end($filename);
        try {
            $context = $this->router->getContext();
            $credendial = $this->connectorService->getCredentials();
            if(!empty($credendial['host'])){
                $context->setHost($credendial['host']);
            }
            $imageContent = $this->connectorService->getImageContentByPath($entry);
            $mimetype = $this->getImageMimeType($imageContent);
            $imageContent = base64_encode($imageContent);

        } catch(\Exception $e) {
            return;
        }

        $convertedItem = [
            'media_type' => 'image',
            'label'      => $productName,
            'position'   => $position,
            'disabled'   => false,
            'types'      => $position ? [] : ["image", "small_image", "thumbnail"],
            'content'    => [
                'base64_encoded_data' => $imageContent,
                'type'                => $this->guessMimetype($mimetype) ? : 'image/png',
                'name'                => $filename,
            ],
        ];
        
        return $convertedItem;
    }

    /**
     * Return a list of attributes to export
     *
     * @param JobParameters $parameters
     *
     * @return array
     */
    protected function getAttributesToFilter(JobParameters $parameters)
    {
        $attributes = $parameters->get('filters')['structure']['attributes'];
        $identifierCode = $this->attributeRepository->getIdentifierCode();
        if (!in_array($identifierCode, $attributes)) {
            $attributes[] = $identifierCode;
        }

        return $attributes;
    }

    /**
     * Are there attributes to filters ?
     *
     * @param JobParameters $parameters
     *
     * @return bool
     */
    protected function areAttributesToFilter(JobParameters $parameters)
    {
         return isset($parameters->get('filters')['structure']['attributes'])
            && !empty($parameters->get('filters')['structure']['attributes']);
    }

    /* add value fillers for product */
    protected function fillProductValues(&$product)
    {
        $product['attribute_set_id']  = 4;;        
    }

    protected function guessMimetype($ext)
    {
        $mimeArray = [
            'png'  => 'image/png',
            'jpe'  => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'jpg'  => 'image/jpeg',
            'gif'  => 'image/gif',
            'bmp'  => 'image/bmp',
            'ico'  => 'image/vnd.microsoft.icon',
            'tiff' => 'image/tiff',
            'tif'  => 'image/tiff',
            'svg'  => 'image/svg+xml',
            'svgz' => 'image/svg+xml',
            'psd' => 'image/vnd.adobe.photoshop',
        ];

        return !empty($mimeArray[$ext]) ? $mimeArray[$ext] : '';
    }

    protected $stockItemFields = [ 
        "qty",
        "is_in_stock",
        "is_qty_decimal",
        "use_config_min_qty",
        "min_qty",
        "use_config_min_sale_qty",
        "min_sale_qty",
        "use_config_max_sale_qty",
        "max_sale_qty",
        "use_config_backorders",
        "backorders",
        "use_config_notify_stock_qty",
        "notify_stock_qty",
        "use_config_qty_increments",
        "qty_increments",
        "use_config_enable_qty_inc",
        "enable_qty_increments",
        "use_config_manage_stock",
        "manage_stock",
        "low_stock_date",
        "is_decimal_divided",
        "stock_status_changed_auto",
    ];
}
