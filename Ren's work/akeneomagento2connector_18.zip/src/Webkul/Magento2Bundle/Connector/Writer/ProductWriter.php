<?php

namespace Webkul\Magento2Bundle\Connector\Writer;

use Akeneo\Component\Batch\Item\ItemWriterInterface;
use Webkul\Magento2Bundle\Component\Normalizer\PropertiesNormalizer;
use Akeneo\Component\Batch\Step\StepExecutionAwareInterface;
use Akeneo\Component\Batch\Model\StepExecution;
use Akeneo\Component\Batch\Item\DataInvalidItem;
use Webkul\Magento2Bundle\Connector\Writer\BaseWriter;
use Webkul\Magento2Bundle\Services\Magento2Connector;
use Webkul\Magento2Bundle\Entity\DataMapping;
use Webkul\Magento2Bundle\Component\OAuthClient;
use Webkul\Magento2Bundle\Traits\DataMappingTrait;

/**
 * Add products to magento2 Api
 *
 * @author    Webkul
 * @copyright 2010-2017 Webkul pvt. ltd.
 * @license   https://store.webkul.com/license.html
 */
class ProductWriter extends BaseWriter implements ItemWriterInterface
{
    use DataMappingTrait;

    const AKENEO_ENTITY_NAME = 'product';

    private $attributeRepo;
    private $familyVariantRepo;

    protected $locale;
    protected $storeViewCurrency;
    protected $channel;
    protected $weightUnit;
    protected $booleanAttributes;
    protected $magentoVersion;
    protected $defaultStoreViewCode;
    protected $otherSettings;

    public function __construct(\Doctrine\ORM\EntityManager $em, Magento2Connector $connectorService, $attributeRepo, $familyVariantRepo)
    {
        $this->em = $em;
        $this->connectorService = $connectorService;
        $this->attributeRepo = $attributeRepo;
        $this->familyVariantRepo = $familyVariantRepo;
    }

    /**
     * write products to magento2 Api
     */
    public function write(array $items)
    {
        if(!$this->oauthClient) {
            $this->setStepExecution->addWarning('invalid oauth client', [], new DataInvalidItem());
            return;    
        }
        
        $parameters = $this->getParameters();
        $storeMappings = $this->getStoreMapping();
        $storeSettings = $this->connectorService->getOtherSettings();
        $this->channel = $this->getChannelScope($this->stepExecution);

        $attributeMappings = $this->connectorService->getAttributeMappings();
        $this->otherSettings = $this->connectorService->getSettings();

        static $productModel;

        foreach($items as $key => $mainItem) {
            $iteration = 0;
            $itemResult = null;
            if(!empty($mainItem['parent']['sku'])) {
                $parentMapping  = $this->getParentMappingBySku($mainItem['parent']['sku']);
            } else {
                $parentMapping = null;
            }

            foreach($storeMappings as $storeViewCode => $storeMapping) {
                $locale = $storeMapping['locale'];
                $this->locale = $locale;
                $this->storeViewCode = $storeViewCode;
                $baseCurrency = !empty($storeSettings[$this->storeViewCode]['base_currency_code']) ? $storeSettings[$this->storeViewCode]['base_currency_code'] : null;
                $this->storeViewCurrency = !empty($storeMapping['currency']) ? $storeMapping['currency'] : $baseCurrency;
                $this->weightUnit = !empty($storeSettings[$this->storeViewCode]['weight_unit']) ? $storeSettings[$this->storeViewCode]['weight_unit'] : null;

                $item = $this->formatData($mainItem);

                if(!$this->defaultStoreViewCode && $iteration === 0) {
                    $this->defaultStoreViewCode = $storeViewCode;
                }

                switch($item[PropertiesNormalizer::FIELD_MAGENTO_PRODUCT_TYPE]) {
                    case 'simple':
                        $product = [self::AKENEO_ENTITY_NAME => $item];
                        $itemResult = $this->addProduct($product);
                        break;
                    case 'variant':
                                   
                        $item[PropertiesNormalizer::FIELD_MAGENTO_PRODUCT_TYPE] = PropertiesNormalizer::SIMPLE_TYPE;
                        $parent = $item['parent'];
                        unset($item['parent']);

                        /* add product model */
                        if(!$parentMapping) {
                            $productModel = $product = $this->addProduct([self::AKENEO_ENTITY_NAME => $parent]); /* parent product */
                            if(!empty($product['id'])) {
                                $this->addMappingByCode($parent['sku'], $product['id']);
                                if(!$iteration) {
                                    $this->quickExportIncrementById($parent['sku']);
                                }                                
                            }
                        }                      

                        $itemResult = $this->addProduct([self::AKENEO_ENTITY_NAME => $item]);   /* child */

                        if($iteration == (-1+count($storeMappings)) ) {
                            $childSku  = $item['sku'];
                            $parentSku = $parent['sku'];
                            if($itemResult && empty($itemResult['error'])) {
                                $this->linkConfigurableChildToParent($childSku, $parentSku);
                                $this->updateProduct($productModel); /* parent product */
                            }
                        }
                        break;
                    case 'virtual':
                        $productData = [self::AKENEO_ENTITY_NAME => $item];
                        $itemResult = $this->addProduct($productData);
                        break;
                    case 'downloadable':
                    case 'bundle':
                    case 'grouped':
                        break;
                }
                $iteration++;                
            }

            if(isset($itemResult) && !isset($itemResult['error']) && !isset($itemResult['message']) ) {
                $this->stepExecution->incrementSummaryInfo('write');

                // Add to Mapping in Database 
                $externalId = !empty($itemResult['id']) ? $itemResult['id'] : null;
                $relatedId = !empty($itemResult['attribute_set_id']) ? $itemResult['attribute_set_id'] : null;
                $code = !empty($itemResult['sku']) ? $itemResult['sku'] : null;
                if($code && $externalId){
                    $mapping = $this->addMappingByCode($code, $externalId, $relatedId, $this::AKENEO_ENTITY_NAME);
                }

            } else {
                if(isset($itemResult['message'])) {
                    $this->stepExecution->addWarning(
                        $itemResult['message'],
                        [], 
                        new DataInvalidItem([
                            'code' => !empty($mainItem['sku']) ? $mainItem['sku'] : '',
                            'debugLine' => __LINE__ 
                        ])
                    );
                }
                $this->stepExecution->incrementSummaryInfo('skipped');
            }
        }
        return null;
    }

    protected function formatData($item)
    {
        $formatted = [
            'custom_attributes' => []
        ];
        
        foreach($item[PropertiesNormalizer::FIELD_META_DATA]['unprocessed'] as $index) {
            if(isset($item[$index])) {
                $val = $this->formatValueForMagento($item[$index]);
                if($index == 'weight') {
                    $val = (float)$val;
                } elseif($index == 'visibility') {
                    if($val) {
                        $val = (int)$val;
                    }
                }
                
                if(in_array($index, ['sku', 'name', 'price', 'status', 'weight', 'visibility'])) {
                    if($val) {
                        $formatted[$index] = $val;
                    }
                } else if(in_array($index, array_keys($this->stockItemAttributes) )) {
                    if(empty($formatted['extension_attributes'])) {
                        $formatted['extension_attributes'] = [];
                    }
                    if($index === 'quantity') {
                        $formatted['extension_attributes']['stock_item'] = [
                            'qty' => (string)(int)$val,
                            'is_in_stock' => true, //(boolean)$val
                            'manage_stock' => true,
                        ];                                        
                    } else {
                        if(null !== $val) {
                            $type = $this->stockItemAttributes[$index];
                            if($type === 'integer')
                            $formatted['extension_attributes']['stock_item'][$index] = (int) $val;
                            if($type === 'boolean') {
                                if($index === 'is_in_stock') {
                                    if(strcasecmp($val, "in_stock") === 0 || $val === true) {
                                        $formatted['extension_attributes']['stock_item'][$index] = true;    
                                    } else {
                                        $formatted['extension_attributes']['stock_item'][$index] = false;    
                                    }
                                } else {
                                    $formatted['extension_attributes']['stock_item'][$index] = (boolean) $val;
                                }
                            }
                            
                            //disable Config settings
                            if(in_array($index , array_keys($this->configSetting) ) ){
                                $formatted['extension_attributes']['stock_item'][ $this->configSetting[$index] ]= false ;
                            }
                            if($index === 'min_qty'){
                                $formatted['extension_attributes']['stock_item']['use_config_min_qty']= 0;
                            }

                            // qty increment present then enable qty increments. 
                            if($index === 'qty_increments'){
                                $formatted['extension_attributes']['stock_item']['enable_qty_increments']= true;
                                $formatted['extension_attributes']['stock_item']['use_config_enable_qty_inc']= false;
                            }   
                        }    
                    }
                    
                } else {
                    $item['custom_attributes'][] = [
                        "attribute_code" => $index,
                        "value"          => $val
                    ];   
                }
            }
        }
  
        foreach(['sku', 'status', 'media_gallery_entries', 'extension_attributes', 'visibility', PropertiesNormalizer::FIELD_MAGENTO_PRODUCT_TYPE] as $rawAttribute) {
            if(isset($item[$rawAttribute]) && !isset($formatted[$rawAttribute]) ) {
                $formatted[$rawAttribute] = $item[$rawAttribute];
            }
        }

        /* categories */ 
        $categories = !empty($item[PropertiesNormalizer::FIELD_META_DATA]['categories']) ? $item[PropertiesNormalizer::FIELD_META_DATA]['categories'] : [];
       
        $catIds = $this->getcategoryIdsFromCategories($categories);

        if(!empty($catIds)) {
            $formatted['custom_attributes'][] = [
                "attribute_code" => "category_ids",
                "value"          => $catIds
            ];         
        }   

        if(!empty($item['custom_attributes'])) {
            foreach($item['custom_attributes'] as $index => $value) {
                $value['value'] = $this->formatValueForMagento($value['value']);
                if($value['attribute_code'] === 'url_key' && !empty($this->otherSettings['urlKeyPrefix']) && $item['type_id'] === 'configurable') {
                    $value['value'] = $this->otherSettings['urlKeyPrefix'] . $value['value'];
                }
                $value['value'] = $this->typeCastValue($value['attribute_code'], $value['value']);

                if(isset($value['attribute_code']) && in_array($value['attribute_code'], $this->getBooleanAttributes()) ) {
                    $value['value'] = (int)$value['value'];
                }
                $formatted['custom_attributes'][] = $value;
            }            
        }

        if(!empty($formatted['custom_attributes'])) {
            $formatted['custom_attributes'] = $this->modifyOptionValues($formatted['custom_attributes']);
        }

        $family = $item[PropertiesNormalizer::FIELD_META_DATA]['family'];
        if($family) {
            $familyMapping = $this->getMappingByCode($family, 'family');
            if($familyMapping) {
                $formatted['attribute_set_id'] = $familyMapping->getExternalId();
            } else {
                $this->stepExecution->addWarning(
                    'Error! family not exported , export family first. code: ' . $family,
                    [], 
                    new DataInvalidItem([
                        'code' => $family,
                        'debugLine' => __LINE__
                    ])
                );  
            }
        }

        if(!empty($item['parent'])) {
            $formatted['parent'] = $this->formatData($item['parent']);
        }

        if(isset($item['axes']) && !empty($formatted['parent'])) {
            $axes = $item['axes'];
            if(!empty($axes)) {
                if(!isset($formatted['parent']['extension_attributes'])) {
                    $formatted['parent']['extension_attributes'] = [];
                }
                if(!isset($formatted['parent']['extension_attributes']['stock_item'])) {
                    $formatted['parent']['extension_attributes']['stock_item'] = [
                        'is_in_stock' => true
                    ];
                }

                $formatted['parent']['extension_attributes']['configurable_product_options'] = [];
                foreach($axes as $attributeCode) {
                    $mapping = $this->getMappingByCode($attributeCode, 'attribute');
                    if($mapping) {
                        $customAttr = [
                            'attribute_id' =>  $mapping->getExternalId(),
                            'label' => $attributeCode,
                            'position' =>  0,
                            'is_use_default' => true,
                            'values' => [
                            ]
                        ] ;
                        $optionMappings = $this->getOptionsByAttributeCode($attributeCode);
                        if($optionMappings) {
                            foreach($optionMappings as $optionMapping) {
                                $customAttr['values'][] = [
                                    'value_index' => $optionMapping->getExternalId(),
                                ];
                            }
                        }

                        $formatted['parent']['extension_attributes']['configurable_product_options'][] = $customAttr;
                    }
                }
            }
        }

        if(!array_key_exists('name', $formatted)) {
            if(!empty($item[PropertiesNormalizer::FIELD_META_DATA]['fallbackName']) ) {
                $value = $this->formatValueForMagento($item[PropertiesNormalizer::FIELD_META_DATA]['fallbackName']);
                $formatted['name'] = $value;
            }
        }
        $attributeMappings = $this->connectorService->getAttributeMappings();
        
        if(!isset($attributeMappings['url_key']) && $this->locale === $this->defaultLocale) {
            $urlKeyString = '';
            if(empty($item['parent']) && 'configurable' === $item['type_id'] ) {
                $urlKeyString = !empty($formatted['name']) ? $formatted['name'] : $formatted['sku'];
                $urlKeyString = (!empty($this->otherSettings['urlKeyPrefix']) ? $this->otherSettings['urlKeyPrefix'] : '') . $urlKeyString;
            } else if(empty($item['parent'])) {
                $urlKeyString = !empty($formatted['name']) ? $formatted['name'] : $formatted['sku'];                
            } elseif($item['type_id'] == 'variant') {
                $urlKeyString = $formatted['sku'];
            }
            if($urlKeyString) {
                $formatted['custom_attributes'][] = [
                    'attribute_code' => 'url_key',
                    'value'         =>  $this->formatUrlKey($urlKeyString),
                ];
            }
        }

        return $formatted;                
    }

    protected function formatUrlKey($string)
    {
        setlocale(LC_ALL, 'en_US.utf8');
        $string = str_replace(["'"], [''], $string);
        $string = iconv('utf-8', 'ascii//TRANSLIT', $string);
        $string = preg_replace('/[^a-zA-Z0-9\']/', '-', $string);

        return $string;    
    }

    protected function modifyOptionValues($data)
    {
        $attributeMappings = $this->connectorService->getAttributeMappings();

        foreach($data as $index => $attr) {
            $realAttrCode = !empty($attributeMappings[$attr['attribute_code']]) ? $attributeMappings[$attr['attribute_code']] : $attr['attribute_code'];
            $attribute = $this->attributeRepo->findOneByIdentifier($realAttrCode);
            if(empty($attribute)) {
                continue;
            }

            if('pim_catalog_date' == $attribute->getType()) {
                $data[$index]['value'] = $this->formatDate($attr['value']);
            } else if(in_array($attribute->getType(), $this->simpleAttributeTypes )) {
            } else if(in_array($attribute->getType(), $this->selectAttributeTypes )) {
                if(is_array($attr['value'])) {
                    $data[$index]['value'] = [];
                    foreach($attr['value'] as $singleValue) {
                        $attributeOption = $this->getMappingByCode($singleValue. '(' . $attribute->getCode() . ')', 'option');
                        if($attributeOption) {
                            $data[$index]['value'][] = (int)$attributeOption->getExternalId(); 
                        }
                    }
                } elseif(gettype($attr['value']) == 'string') {
                    $attributeOption = $this->getMappingByCode($attr['value']. '(' . $attribute->getCode() . ')', 'option');
                    if($attributeOption) {
                        $data[$index]['value'] = $attributeOption->getExternalId(); 
                    } else {
                        $data[$index]['value'] = 0;
                        // unset($data[$index]);
                    }
                }
            }

            if(!empty($data[$index])) {
                $data[$index]['attribute_code'] = strtolower($data[$index]['attribute_code']); 
            }
        }

        return $data;
    }

    protected function getcategoryIdsFromCategories($categories) 
    {
        $catIds = [];
        foreach($categories as $categoryCode) {
            $mapping = $this->getMappingByCode($categoryCode, 'category');
            if($mapping && $mapping->getExternalId()) {
                $catIds[] = $mapping->getExternalId() ;
            }                            
        }

        return $catIds;
    }
    

    protected function linkConfigurableChildToParent($childSku, $parentSku)
    {
        
        if(!empty($childSku) && !empty($parentSku) ) {
            $url = $this->getApiUrlByEndpoint('addChild');
            $url = str_replace('{sku}', urlencode($parentSku), $url);

            $postData = [
                'childSku' => $childSku
            ];
            
            try {
                $lastResponse = $this->oauthClient->fetch($url, json_encode($postData), 'POST', $this->jsonHeaders );
                
                // $this->stepExecution->addSummaryInfo($childSku ,$this->oauthClient->getLastResponse());
            } catch(\Exception $e) {
                $lastResponse = json_decode($this->oauthClient->getLastResponse(), true );
                if(!empty($lastResponse['error']['message']) || !empty($lastResponse['message'] && !in_array($lastResponse['message'], $this->linkSkuGeneralMsgs))) {
                    $this->stepExecution->addWarning(
                        'link sku error:' .  
                        (!empty($lastResponse['error']['message']) ? $lastResponse['error']['message'] : $lastResponse['message']) ,
                        ['error' => true ], 
                        new DataInvalidItem([
                            'sku' => $childSku,
                            'debugLine' => __LINE__
                            ])
                    );             
                }
            }
        }   
    }

    private function formatValueForMagento($value)
    {
        if(is_array($value)) {
            foreach($value as $key => $aValue) {

                if(is_array($aValue) ) {
                    if(isset($aValue['scope']) &&  $aValue['scope'] !== $this->channel) {

                        continue;
                    }
                    if(array_key_exists('locale', $aValue)) {
                        if(!$aValue['locale'] || $aValue['locale'] == $this->locale) {
                            $newValue = $aValue['data']; 
                            break;
                        }
                    } else {
                        break;
                    }
                } else {
                    break;
                }
            }
        }
        $value = isset($newValue) ? $newValue : null;
        if($value && is_array($value) ) {
            /* price */ 
            foreach($value as $key => $aValue) {
                if(is_array($aValue)) {
                    if(array_key_exists('currency', $aValue)) {
                        if(!$aValue['currency'] || $aValue['currency'] == $this->storeViewCurrency) {
                            $value = (float)$aValue['amount'];
                            break;
                        }
                        if($key == count($value)-1) {
                            $value = !empty($value[0]['amount']) ? $value[0]['amount'] : null ;
                            $value = (float)$value;
                        }
                    }

                } else {
                    break;
                }
            }
            /* metric */
            if(is_array($value) && array_key_exists('unit', $value)) {
                $tmpValue = $value; 
                $value = !empty($value['amount']) ? (float)$value['amount'] : null;

                if(!empty($this->otherSettings['metric_selection']) && $this->otherSettings['metric_selection'] == "true"){
                    $value = !empty($value) ? (string) $value . ' ' . $tmpValue['unit'] : $value;
                }
            }
        }
        if(null === $value) {
            $value = '';
        }
        
        return $value;
    }


    /* attribute sets */
    private $attributeSet;
    public function getAttributeSets()
    {
        if(!$this->attributeSet) {
            $url = $this->getApiUrlByEndpoint('attributeSets');
            $this->oauthClient->fetch($url, null, 'GET', $this->jsonHeaders);
            $this->attributeSet = json_decode($this->oauthClient->getLastResponse(), true);

        }

        return $this->attributeSet;
    }

    protected function getParentMappingBySku($sku)
    {
        $parentMapping = $this->getMappingByCode($sku, self::AKENEO_ENTITY_NAME);
        if($parentMapping && $this->stepExecution->getJobExecution()->getId() !== $parentMapping->getJobInstanceId() ) {
            $this->em->remove($parentMapping);
            $this->em->flush();
            $parentMapping = null;
        }

        return $parentMapping;
    }

    protected function addProduct($productData)
    {
        if(!empty($productData) ) {
            /* similar data in all store view */
            if($this->storeViewCode === $this->defaultStoreViewCode) {
                $baseData = $this->checkProductAndModifyData($productData, 'all');
                if(!empty($baseData)) {
                    $productAddUrl = $this->getApiUrlByEndpoint(self::AKENEO_ENTITY_NAME, 'all');
                    try {
                        $this->oauthClient->fetch($productAddUrl, is_array($baseData) ? json_encode($baseData) : $baseData, 'POST', $this->jsonHeaders );
                        // return json_decode($this->oauthClient->getLastResponse(), true);
                    } catch(\Exception $e) {
                    }
                }
            }
            $productData = $this->checkProductAndModifyData($productData, $this->storeViewCode);
            $productAddUrl = $this->getApiUrlByEndpoint(self::AKENEO_ENTITY_NAME, $this->storeViewCode);

            try {
                $this->oauthClient->fetch($productAddUrl, is_array($productData) ? json_encode($productData) : $productData, 'POST', $this->jsonHeaders );
                /* log success */
                return json_decode($this->oauthClient->getLastResponse(), true);
            } catch(\Exception $e) {
                /* log error */
                $lastResponse = json_decode($this->oauthClient->getLastResponse(), true );
                $sendData = $productData;
                if(!empty($sendData['product']['media_gallery_entries'])) {
                    unset($sendData['product']['media_gallery_entries']);
                }

                $this->stepExecution->addWarning(
                    !empty($lastResponse['message']) ? $lastResponse['message'] : $this->oauthClient->getLastResponse(),
                    [], 
                    new DataInvalidItem([
                        'sku' => !empty($productData[self::AKENEO_ENTITY_NAME]['sku']) ? $productData[self::AKENEO_ENTITY_NAME]['sku'] : 'sku not found',
                        'debugLine' => __LINE__,
                        'requestData' => $sendData,
                        'responseData' => $this->oauthClient->getLastResponse(), true,
                    ]
                ));

                return ['error' => json_decode($this->oauthClient->getLastResponse(), true)];
            }
        }
    }

    protected function updateProduct($product)
    {
        if($product && empty($product['error'])) {
            /* fetch product */
            $productData = [
                self::AKENEO_ENTITY_NAME => [ 'custom_attributes' => [] ]
            ];

            $customAttributes = [];
            foreach($product['custom_attributes'] as $attribute) {
                if(in_array($attribute['attribute_code'], ['image', 'thumbnail', 'small_image', 'url_key'] ) && $attribute['value'] !== "no_selection") {
                    $customAttributes[] = $attribute;
                }
            }
            
            $productData[self::AKENEO_ENTITY_NAME]['custom_attributes'] = $customAttributes;
            if(!empty($productData) && !empty($customAttributes) ) {
                $url = $this->getApiUrlByEndpoint('getProduct');
                $url = str_replace('{sku}', urlencode($product['sku']), $url);

                try {
                    $this->oauthClient->fetch($url, is_array($productData) ? json_encode($productData) : $productData, 'PUT', $this->jsonHeaders );
                    return json_decode($this->oauthClient->getLastResponse(), true);
                } catch(\Exception $e) {
                    /* log error */
                    $this->stepExecution->addWarning($this->oauthClient->getLastResponse() , ['error' => true ], new DataInvalidItem([
                        'sku' => !empty($productData[self::AKENEO_ENTITY_NAME]['sku']) ? $productData[self::AKENEO_ENTITY_NAME]['sku'] : 'sku not found',
                        'debugLine' => __LINE__                        
                    ]));

                    return ['error' => json_decode($this->oauthClient->getLastResponse(), true)];
                }
            }
        }
    }

    protected function checkProductAndModifyData($productData, $storeViewCode)
    {
        $url = $this->getApiUrlByEndpoint('getProduct', $storeViewCode);
        $url = str_replace('{sku}', urlencode($productData[self::AKENEO_ENTITY_NAME]['sku']), $url);
        
        /* fetch product */
        try {
            $this->oauthClient->fetch($url, null, 'GET', $this->jsonHeaders);
            $response = json_decode($this->oauthClient->getLastResponse(), true);
        } catch(\Exception $e) {
            $response = [];
        }

        if($productData[self::AKENEO_ENTITY_NAME]['type_id'] === 'configurable' && !empty($response['extension_attributes']['configurable_product_links']) ) {
            if(empty($productData[self::AKENEO_ENTITY_NAME]['extension_attributes'])) {
                $productData[self::AKENEO_ENTITY_NAME]['extension_attributes'] = [];
            }
            $productData[self::AKENEO_ENTITY_NAME]['extension_attributes']['configurable_product_links'] =  $response['extension_attributes']['configurable_product_links'];
        }

        $existingImages = [];
        $attributeMappings = $this->connectorService->getAttributeMappings();

        if(!empty($response['media_gallery_entries'])) {
            if(empty($productData[self::AKENEO_ENTITY_NAME]['custom_attributes'])) {
                $productData[self::AKENEO_ENTITY_NAME]['custom_attributes'] = [];
            }
            foreach($response['media_gallery_entries'] as $image) {
                if(isset($image['file'])) {
                    $existingImages[] = $image['file'];
                    foreach(['image', 'small_image', 'thumbnail'] as $field) {
                        if(in_array($field, $image['types']) && !in_array($field, array_keys($attributeMappings))) {
                            $productData[self::AKENEO_ENTITY_NAME]['custom_attributes'][] = [
                                'attribute_code' => $field,
                                'value'         =>  $image['file'],
                            ];
                        }
                    }
                }
            }
        }

        if(!empty($existingImages)) {
            $mediaEntries = $productData[self::AKENEO_ENTITY_NAME]['media_gallery_entries'];
            foreach($mediaEntries as $key => $mediaEntry) {
                if(isset($mediaEntry['content']['name'])) {
                    $nameArray = explode('.', $mediaEntry['content']['name'] );
                    $name = reset($nameArray);

                    if(count(preg_grep('#' . $name . '#', $existingImages))) {
                        unset($mediaEntries[$key]);                
                    }
                }
            }

            $mediaEntries = array_values($mediaEntries);
            if(empty($mediaEntries)) {
                unset($productData[self::AKENEO_ENTITY_NAME]['media_gallery_entries']);
            } else {
                if(count($mediaEntries) === count($productData[self::AKENEO_ENTITY_NAME]['media_gallery_entries'])) {
                    $productData[self::AKENEO_ENTITY_NAME]['media_gallery_entries'] = $mediaEntries;
                }
            }
        }

        return $productData;
    }

    protected $lastIncrementSku;
    protected function quickExportIncrementById($sku)
    {
        $params = $this->getParameters();
        $isQuickExport = !empty($params['filters']['0']['context']);

        if($isQuickExport && $sku !== $this->lastIncrementSku) {
            $this->lastIncrementSku = $sku;
            $this->stepExecution->incrementSummaryInfo('write');            
        } 
    }

    protected function getBooleanAttributes()
    {
        if(!$this->booleanAttributes && gettype($this->booleanAttributes) !== 'array') {
            $this->booleanAttributes = $this->attributeRepo->getAttributeCodesByType(
                'pim_catalog_boolean'
            );
        }

        return $this->booleanAttributes;
    }

    protected function typeCastValue($code, $value)
    {
        if(in_array($code, array_keys($this->strictTypes))) {
            switch($this->strictTypes[$code]) {
                case 'string':
                    $value = (string)$value;
                    break;
                case 'integer':
                case 'int':
                    $value = (int)$value;
                    break;
            }
        }

        return $value;
    }

    private function getOptionsByAttributeCode($code)
    {
        $mappings = $this->mappingRepository->getOptionsByAttributeCode($code);

        return $mappings;
    }

    private function formatDate($date)
    {
        $dateObj = new \DateTime($date);

        return $dateObj->format('Y-m-d H:i:s');
    }

    protected $simpleAttributeTypes = ['pim_catalog_text', 'pim_catalog_number','pim_catalog_textarea','pim_catalog_date','pim_catalog_boolean'];

    protected $selectAttributeTypes = ['pim_catalog_multiselect', 'pim_catalog_simpleselect'];

    protected $strictTypes = [
        'description'       => 'string',
        'short_description' => 'string',
        'thumbnail_label'   => 'string',
        'small_image_label' => 'string',
        'image_label'       => 'string',
        'visibility'        => 'int',
        'status'            => 'int',
        'has_options'       => 'int',
        'tax_class_id'      => 'int',
    ];
    
    protected $linkSkuGeneralMsgs = [
        'Produkt wurde bereits angehängt',
        'Product has already been attached',
        'Product has been already attached',
        'Le produit a déjà été attaché',
        'Product is al bijgevoegd',
    ];

    protected $stockItemAttributes = [
        "quantity" => 'integer',
        "qty" => 'integer',
        "is_in_stock" => 'boolean',
        "is_qty_decimal" => 'boolean',
        "use_config_min_qty" => 'integer',
        "min_qty" => 'integer',
        "use_config_min_sale_qty" => 'int',
        "min_sale_qty" => 'integer',
        "use_config_max_sale_qty" => 'boolean',
        "max_sale_qty" => 'integer',
        "use_config_backorders" => 'boolean',
        "backorders" => 'integer',
        "use_config_notify_stock_qty" => 'boolean',
        "notify_stock_qty" => 'integer',
        "use_config_qty_increments" => 'boolean',
        "qty_increments" => 'integer',
        "use_config_enable_qty_inc" => 'boolean',
        "enable_qty_increments" => 'boolean',
        "use_config_manage_stock" => 'boolean',
        "manage_stock" => 'boolean',
        "low_stock_date" => 'boolean',
        "is_decimal_divided" => 'boolean',
        "stock_status_changed_auto" => 'integer',
    ];

    protected $configSetting = [
        "min_qty" =>  "use_config_min_qty",
        "max_sale_qty" => "use_config_max_sale_qty",
        "backorders" => "use_config_backorders",
        "notify_stock_qty" => "use_config_notify_stock_qty",
        "qty_increments" => "use_config_qty_increments",
        "enable_qty_increments" => "use_config_enable_qty_inc",
        "manage_stock" => "use_config_manage_stock",
    ];
    
}

