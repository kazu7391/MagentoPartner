<?php

namespace Webkul\Magento2Bundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class Magento2Bundle extends Bundle
{
}
